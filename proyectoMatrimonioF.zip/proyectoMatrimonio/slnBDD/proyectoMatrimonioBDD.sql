
/*==============================================================*/
/* DBMS name:      SQL SERVER 2018                              */
/* Created on:     04/02/2019 22:52:14                          */
/*==============================================================*/

use master 
go

create database proyectoMatrimonioBDD
go

use proyectoMatrimonioBDD
go


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CABECERA_FORMULARIO') and o.name = 'FK_CABECERA_RELATIONS_REGISTRO')
alter table CABECERA_FORMULARIO
   drop constraint FK_CABECERA_RELATIONS_REGISTRO
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CABECERA_FORMULARIO') and o.name = 'FK_CABECERA_RELATIONS_CUERPO_F')
alter table CABECERA_FORMULARIO
   drop constraint FK_CABECERA_RELATIONS_CUERPO_F
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONTRAYENTE_FEM') and o.name = 'FK_CONTRAYEFEM_RELATIONS_CUERPO_F')
alter table CONTRAYENTE_FEM
   drop constraint FK_CONTRAYEFEM_RELATIONS_CUERPO_F
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CONTRAYENTE_MASC') and o.name = 'FK_CONTRAYEMASC_RELATIONS_CUERPO_F')
alter table CONTRAYENTE_MASC
   drop constraint FK_CONTRAYEMASC_RELATIONS_CUERPO_F
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CUERPO_FORMULARIO') and o.name = 'FK_CUERPO_F_RELATIONS_CABECERA')
alter table CUERPO_FORMULARIO
   drop constraint FK_CUERPO_F_RELATIONS_CABECERA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CUERPO_FORMULARIO') and o.name = 'FK_CUERPOMASC_RELATIONS_CONTRAYE')
alter table CUERPO_FORMULARIO
   drop constraint FK_CUERPOMASC_RELATIONS_CONTRAYE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CUERPO_FORMULARIO') and o.name = 'FK_CUERPOFEM_RELATIONS_CONTRAYE')
alter table CUERPO_FORMULARIO
   drop constraint FK_CUERPOFEM_RELATIONS_CONTRAYE
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('CUERPO_FORMULARIO') and o.name = 'FK_CUERPO_F_RELATIONS_RESPONSA')
alter table CUERPO_FORMULARIO
   drop constraint FK_CUERPO_F_RELATIONS_RESPONSA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('RESPONSABLE') and o.name = 'FK_RESPONSA_RELATIONS_CUERPO_F')
alter table RESPONSABLE
   drop constraint FK_RESPONSA_RELATIONS_CUERPO_F
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CABECERA_FORMULARIO')
            and   name  = 'RELATIONSHIP_9_FK'
            and   indid > 0
            and   indid < 255)
   drop index CABECERA_FORMULARIO.RELATIONSHIP_9_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CABECERA_FORMULARIO')
            and   name  = 'RELATIONSHIP_1_FK'
            and   indid > 0
            and   indid < 255)
   drop index CABECERA_FORMULARIO.RELATIONSHIP_1_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CABECERA_FORMULARIO')
            and   type = 'U')
   drop table CABECERA_FORMULARIO
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONTRAYENTE_FEM')
            and   name  = 'RELATIONSHIP_6_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONTRAYENTE_FEM.RELATIONSHIP_6_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONTRAYENTE_FEM')
            and   type = 'U')
   drop table CONTRAYENTE_FEM
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CONTRAYENTE_MASC')
            and   name  = 'RELATIONSHIP_4_FK'
            and   indid > 0
            and   indid < 255)
   drop index CONTRAYENTE_MASC.RELATIONSHIP_4_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CONTRAYENTE_MASC')
            and   type = 'U')
   drop table CONTRAYENTE_MASC
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CUERPO_FORMULARIO')
            and   name  = 'RELATIONSHIP_10_FK'
            and   indid > 0
            and   indid < 255)
   drop index CUERPO_FORMULARIO.RELATIONSHIP_10_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CUERPO_FORMULARIO')
            and   name  = 'RELATIONSHIP_7_FK'
            and   indid > 0
            and   indid < 255)
   drop index CUERPO_FORMULARIO.RELATIONSHIP_7_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CUERPO_FORMULARIO')
            and   name  = 'RELATIONSHIP_5_FK'
            and   indid > 0
            and   indid < 255)
   drop index CUERPO_FORMULARIO.RELATIONSHIP_5_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('CUERPO_FORMULARIO')
            and   name  = 'RELATIONSHIP_3_FK'
            and   indid > 0
            and   indid < 255)
   drop index CUERPO_FORMULARIO.RELATIONSHIP_3_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('CUERPO_FORMULARIO')
            and   type = 'U')
   drop table CUERPO_FORMULARIO
go

if exists (select 1
            from  sysobjects
           where  id = object_id('REGISTRO_CIVIL')
            and   type = 'U')
   drop table REGISTRO_CIVIL
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('RESPONSABLE')
            and   name  = 'RELATIONSHIP_8_FK'
            and   indid > 0
            and   indid < 255)
   drop index RESPONSABLE.RELATIONSHIP_8_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('RESPONSABLE')
            and   type = 'U')
   drop table RESPONSABLE
go

/*==============================================================*/
/* Table: CABECERA_FORMULARIO                                   */
/*==============================================================*/
create table CABECERA_FORMULARIO (
   IDCAB                int IDENTITY(1,1)    not null,
   IDCUE                int                  null,
   IDOFIC               int                  not null,
   FECHACAB             varchar(50)          not null,
   USOINECCAB           int                  not null,
   FECHAINEC            varchar(50)          not null,
   ACTACAB              int                  not null,
   NUMHIJOSCAB          int                  not null,
   CAPBIENESCAB         varchar(2)           not null,
   constraint PK_CABECERA_FORMULARIO primary key nonclustered (IDCAB)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_1_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_1_FK on CABECERA_FORMULARIO (
IDOFIC ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_9_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_9_FK on CABECERA_FORMULARIO (
IDCUE ASC
)
go

/*==============================================================*/
/* Table: CONTRAYENTE_FEM                                       */
/*==============================================================*/
create table CONTRAYENTE_FEM (
   DNIFEM               int                  not null,
   IDCUE                int                  null,
   NOMBREFEM            varchar(50)          not null,
   FECHANACFEM          varchar(50)          not null,
   EDADFEM              int                  not null,
   NUMMATRIFEM          int                  not null,
   NACIONFEM            varchar(20)          not null,
   PAISEXTFEM           varchar(50)          null,
   USOINECEXTFEM        int                  null,
   ESTCIVILFEM          varchar(20)          not null,
   ETNIAFEM             varchar(20)          not null,
   LEERFEM              varchar(2)           not null,
   INSTRUCCIONFEM       varchar(50)          not null,
   PROVFEM              varchar(50)          not null,
   CANTONFEM            varchar(50)          not null,
   PARROQUIAFEM         varchar(50)          not null,
   LOCALFEM             varchar(50)          not null,
   USOINECFEM           int                  not null,
   constraint PK_CONTRAYENTE_FEM primary key nonclustered (DNIFEM)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_6_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_6_FK on CONTRAYENTE_FEM (
IDCUE ASC
)
go

/*==============================================================*/
/* Table: CONTRAYENTE_MASC                                      */
/*==============================================================*/
create table CONTRAYENTE_MASC (
   DNIMASC              int                  not null,
   IDCUE                int                  null,
   NOMBREMASC           varchar(50)          not null,
   FECHANACMASC         varchar(50)             not null,
   EDADMASC             int                  not null,
   NUMMATRIMASC         int                  not null,
   NACIONMASC           varchar(20)          not null,
   PAISEXTMASC          varchar(50)          null,
   USOINECEXTMASC       int                  null,
   ESTCIVILMASC         varchar(20)          not null,
   ETNIAMASC            varchar(20)          not null,
   LEERMASC             varchar(2)           not null,
   INSTRUCCIONMASC      varchar(50)          not null,
   PROVMASC             varchar(50)          not null,
   CANTONMASC           varchar(50)          not null,
   PARROQUIAMASC        varchar(50)          not null,
   LOCALMASC            varchar(50)          not null,
   USOINECMASC          int                  not null,
   constraint PK_CONTRAYENTE_MASC primary key nonclustered (DNIMASC)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_4_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_4_FK on CONTRAYENTE_MASC (
IDCUE ASC
)
go

/*==============================================================*/
/* Table: CUERPO_FORMULARIO                                     */
/*==============================================================*/
create table CUERPO_FORMULARIO (
   IDCUE                int IDENTITY(1000,1) not null,
   DNIRESP              int                  null,
   DNIMASC              int                  null,
   IDCAB                int                  null,
   DNIFEM               int                  null,
   USOINECCUE           int                  not null,
   OBSCUE               varchar(50)          null,
   constraint PK_CUERPO_FORMULARIO primary key nonclustered (IDCUE)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_3_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_3_FK on CUERPO_FORMULARIO (
DNIMASC ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_5_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_5_FK on CUERPO_FORMULARIO (
DNIFEM ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_7_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_7_FK on CUERPO_FORMULARIO (
DNIRESP ASC
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_10_FK                                    */
/*==============================================================*/
create index RELATIONSHIP_10_FK on CUERPO_FORMULARIO (
IDCAB ASC
)
go

/*==============================================================*/
/* Table: REGISTRO_CIVIL                                        */
/*==============================================================*/
create table REGISTRO_CIVIL (
   IDOFIC               int                  not null,
   NOMBREOFIC           varchar(50)          not null,
   NUMOFIC              int                  not null,
   PROVOFIC             varchar(50)          not null,
   CANTONOFIC           varchar(50)          not null,
   PARROQUIAOFIC        varchar(50)          not null,
   constraint PK_REGISTRO_CIVIL primary key nonclustered (IDOFIC)
)
go

/*==============================================================*/
/* Table: RESPONSABLE                                           */
/*==============================================================*/
create table RESPONSABLE (
   DNIRESP              int                  not null,
   IDCUE                int                  null,
   NOMBRERESP           varchar(50)          not null,
   constraint PK_RESPONSABLE primary key nonclustered (DNIRESP)
)
go

/*==============================================================*/
/* Index: RELATIONSHIP_8_FK                                     */
/*==============================================================*/
create index RELATIONSHIP_8_FK on RESPONSABLE (
IDCUE ASC
)
go

alter table CABECERA_FORMULARIO
   add constraint FK_CABECERA_RELATIONS_REGISTRO foreign key (IDOFIC)
      references REGISTRO_CIVIL (IDOFIC)
go

alter table CABECERA_FORMULARIO
   add constraint FK_CABECERA_RELATIONS_CUERPO_F foreign key (IDCUE)
      references CUERPO_FORMULARIO (IDCUE)
go

alter table CONTRAYENTE_FEM
   add constraint FK_CONTRAYEFEM_RELATIONS_CUERPO_F foreign key (IDCUE)
      references CUERPO_FORMULARIO (IDCUE)
go

alter table CONTRAYENTE_MASC
   add constraint FK_CONTRAYEMASC_RELATIONS_CUERPO_F foreign key (IDCUE)
      references CUERPO_FORMULARIO (IDCUE)
go

alter table CUERPO_FORMULARIO
   add constraint FK_CUERPO_F_RELATIONS_CABECERA foreign key (IDCAB)
      references CABECERA_FORMULARIO (IDCAB)
go

alter table CUERPO_FORMULARIO
   add constraint FK_CUERPOMASC_RELATIONS_CONTRAYE foreign key (DNIMASC)
      references CONTRAYENTE_MASC (DNIMASC)
go

alter table CUERPO_FORMULARIO
   add constraint FK_CUERPOFEM_RELATIONS_CONTRAYE foreign key (DNIFEM)
      references CONTRAYENTE_FEM (DNIFEM)
go

alter table CUERPO_FORMULARIO
   add constraint FK_CUERPO_F_RELATIONS_RESPONSA foreign key (DNIRESP)
      references RESPONSABLE (DNIRESP)
go

alter table RESPONSABLE
   add constraint FK_RESPONSA_RELATIONS_CUERPO_F foreign key (IDCUE)
      references CUERPO_FORMULARIO (IDCUE)
go

/*==============================================================*/
/* Table: AUDITORIA                                            */
/*==============================================================*/

create table AUDITORIA(
IDCUE int not null,
DNIRESP int not null,
DNIMASC int not null,
IDCAB int not null,
DNIFEM int not null,
USOINECCUE int not null,
OBSCUE varchar(50)
)
GO

/*==============================================================*/
/* Eliminar Restricciones de llaves foraneas para permitir la   */
/* insercion de datos sin conflictos                            */
/*==============================================================*/

ALTER TABLE CABECERA_FORMULARIO  
NOCHECK CONSTRAINT FK_CABECERA_RELATIONS_CUERPO_F;
GO
ALTER TABLE CABECERA_FORMULARIO  
NOCHECK CONSTRAINT FK_CABECERA_RELATIONS_REGISTRO;   
GO



ALTER TABLE CONTRAYENTE_FEM  
NOCHECK CONSTRAINT FK_CONTRAYEFEM_RELATIONS_CUERPO_F;
GO



ALTER TABLE CONTRAYENTE_MASC  
NOCHECK CONSTRAINT FK_CONTRAYEMASC_RELATIONS_CUERPO_F;   
GO



ALTER TABLE CUERPO_FORMULARIO  
NOCHECK CONSTRAINT FK_CUERPO_F_RELATIONS_CABECERA;   
GO
ALTER TABLE CUERPO_FORMULARIO  
NOCHECK CONSTRAINT FK_CUERPO_F_RELATIONS_RESPONSA;   
GO
ALTER TABLE CUERPO_FORMULARIO  
NOCHECK CONSTRAINT FK_CUERPOFEM_RELATIONS_CONTRAYE;   
GO
ALTER TABLE CUERPO_FORMULARIO  
NOCHECK CONSTRAINT FK_CUERPOMASC_RELATIONS_CONTRAYE;   
GO



ALTER TABLE RESPONSABLE 
NOCHECK CONSTRAINT FK_RESPONSA_RELATIONS_CUERPO_F;   
GO


/*==============================================================*/
/* TABLA: USUARIOS					                            */
/*==============================================================*/

CREATE TABLE USUARIOS(
idUsuario int identity(10000,1) not null,
usuario varchar(30) not null,
pass varchar(30) not null)
go

/*==============================================================*/
/* INSERCION DEL USUARIO PARA LOGIN                             */
/*==============================================================*/

insert into USUARIOS(usuario, pass) values ('admin', 'admin')
go


/*==============================================================*/
/* TRIGGER PARA LA AUDITORIA                                    */
/*==============================================================*/

CREATE TRIGGER AuditoriaForm
on
CUERPO_FORMULARIO
after insert
as
begin
	insert AUDITORIA select * from inserted
end
go

select * from AUDITORIA
/*==============================================================*/
/* Validar que el valor de la cedula del responsable no sea 0 
en tabla CUERPO_FORMULARIO                                      */
/*==============================================================*/

CREATE TRIGGER validarIngresoEnterosDNIRESP
on
CUERPO_FORMULARIO
for insert
as
begin
	if(select DNIRESP from inserted)<=0
	begin
		ROLLBACK TRANSACTION
		PRINT 'No se puede resgistrar valor 0'
	end
		else
			PRINT 'Ingreso realizado correctamente'
		end
go


/*==============================================================*/
/* Validar que el valor de la cedula del contrayente no sea 0 
en tabla CUERPO_FORMULARIO                                      */
/*==============================================================*/

CREATE TRIGGER validarIngresoEnterosDNIMASC
on
CUERPO_FORMULARIO
for insert
as
begin
	if(select DNIMASC from inserted)<=0
	begin
		ROLLBACK TRANSACTION
		PRINT 'No se puede resgistrar valor 0'
	end
		else
			PRINT 'Ingreso realizado correctamente'
		end
go


/*==============================================================*/
/* Validar que el valor del idcabecera del formulario no sea 0 
en tabla CUERPO_FORMULARIO                                      */
/*==============================================================*/

CREATE TRIGGER validarIngresoEnterosIDCAB
on
CUERPO_FORMULARIO
for insert
as
begin
	if(select IDCAB from inserted)<=0
	begin
		ROLLBACK TRANSACTION
		PRINT 'No se puede resgistrar valor 0'
	end
		else
			PRINT 'Ingreso realizado correctamente'
		end
go


/*==============================================================*/
/* Validar que el valor de la cedula de la contrayente no sea 0 
en tabla CUERPO_FORMULARIO                                      */
/*==============================================================*/

CREATE TRIGGER validarIngresoEnterosDNIFEM
on
CUERPO_FORMULARIO
for insert
as
begin
	if(select DNIFEM from inserted)<=0
	begin
		ROLLBACK TRANSACTION
		PRINT 'No se puede resgistrar valor 0'
	end
		else
			PRINT 'Ingreso realizado correctamente'
		end
go



/*==============================================================*/
/* Validar que el valor de USOINEC no sea 0 
en tabla CUERPO_FORMULARIO                                      */
/*==============================================================*/

CREATE TRIGGER validarIngresoEnterosUSOINEC
on
CUERPO_FORMULARIO
for insert
as
begin
	if(select USOINECCUE from inserted)<=0
	begin
		ROLLBACK TRANSACTION
		PRINT 'No se puede resgistrar valor 0'
	end
		else
			PRINT 'Ingreso realizado correctamente'
		end
go




CREATE VIEW informacion 
as
select CA.IDCAB, CA.IDCUE, CA.FECHACAB, CF.NOMBREFEM, CM.NOMBREMASC FROM CONTRAYENTE_FEM CF JOIN CONTRAYENTE_MASC CM
ON CF.IDCUE = CM.IDCUE JOIN CABECERA_FORMULARIO CA
ON CM.IDCUE = CA.IDCUE
go




/*==============================================================*/
/* 
insert into CUERPO_FORMULARIO(DNIRESP, DNIMASC, IDCAB, DNIFEM, USOINECCUE, OBSCUE)
values
(0,35135,351351,35135,3513,'papu')

select * from AUDITORIA

select * from USUARIOS where usuario = 'admin' AND pass = 'admin'                          */
/*==============================================================*/

select *from CONTRAYENTE_FEM 