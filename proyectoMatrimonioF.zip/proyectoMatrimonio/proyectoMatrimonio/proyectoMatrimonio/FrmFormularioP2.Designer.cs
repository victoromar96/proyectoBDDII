﻿namespace proyectoMatrimonio
{
    partial class FrmFormularioP2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtNumMatriFEM = new System.Windows.Forms.TextBox();
            this.label42 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label40 = new System.Windows.Forms.Label();
            this.dateFechaNacFEM = new System.Windows.Forms.DateTimePicker();
            this.label39 = new System.Windows.Forms.Label();
            this.txtUInecFEM = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtLocalFEM = new System.Windows.Forms.TextBox();
            this.txtParroFEM = new System.Windows.Forms.TextBox();
            this.txtCantonFEM = new System.Windows.Forms.TextBox();
            this.txtProvFEM = new System.Windows.Forms.TextBox();
            this.label37 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.cmbInstrucFEM = new System.Windows.Forms.ComboBox();
            this.label32 = new System.Windows.Forms.Label();
            this.label31 = new System.Windows.Forms.Label();
            this.cmbEtniaFEM = new System.Windows.Forms.ComboBox();
            this.label30 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label25 = new System.Windows.Forms.Label();
            this.txtDniFEM = new System.Windows.Forms.TextBox();
            this.label24 = new System.Windows.Forms.Label();
            this.label23 = new System.Windows.Forms.Label();
            this.txtINECExtFEM = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtPaisFEM = new System.Windows.Forms.TextBox();
            this.label21 = new System.Windows.Forms.Label();
            this.label20 = new System.Windows.Forms.Label();
            this.txtNombreFEM = new System.Windows.Forms.TextBox();
            this.label19 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.txtNombreRespCUE = new System.Windows.Forms.TextBox();
            this.txtCedulaRespCUE = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtObsCUE = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtUInecCUER = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.btnRegistrar = new System.Windows.Forms.Button();
            this.txtEdadFEM = new System.Windows.Forms.TextBox();
            this.cmbLeerFEM = new System.Windows.Forms.ComboBox();
            this.cmbEstCivilFEM = new System.Windows.Forms.ComboBox();
            this.cmbNacionFEM = new System.Windows.Forms.ComboBox();
            this.button1 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // txtNumMatriFEM
            // 
            this.txtNumMatriFEM.Location = new System.Drawing.Point(363, 318);
            this.txtNumMatriFEM.Name = "txtNumMatriFEM";
            this.txtNumMatriFEM.Size = new System.Drawing.Size(100, 20);
            this.txtNumMatriFEM.TabIndex = 111;
            this.txtNumMatriFEM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumMatriFEM_KeyPress);
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(360, 295);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(226, 13);
            this.label42.TabIndex = 110;
            this.label42.Text = "NÚMERO DE MATRIMONIOS ANTERIORES";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(17, 318);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(201, 13);
            this.label41.TabIndex = 108;
            this.label41.Text = "Años cumplidos a la fecha del matrimonio";
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(17, 295);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(37, 13);
            this.label40.TabIndex = 107;
            this.label40.Text = "EDAD";
            // 
            // dateFechaNacFEM
            // 
            this.dateFechaNacFEM.Location = new System.Drawing.Point(20, 253);
            this.dateFechaNacFEM.Name = "dateFechaNacFEM";
            this.dateFechaNacFEM.Size = new System.Drawing.Size(246, 20);
            this.dateFechaNacFEM.TabIndex = 106;
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(17, 232);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(130, 13);
            this.label39.TabIndex = 105;
            this.label39.Text = "FECHA DE NACIMIENTO";
            // 
            // txtUInecFEM
            // 
            this.txtUInecFEM.Location = new System.Drawing.Point(1022, 270);
            this.txtUInecFEM.Name = "txtUInecFEM";
            this.txtUInecFEM.Size = new System.Drawing.Size(233, 20);
            this.txtUInecFEM.TabIndex = 104;
            this.txtUInecFEM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUInecFEM_KeyPress);
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(1107, 242);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(58, 13);
            this.label38.TabIndex = 103;
            this.label38.Text = "USO INEC";
            // 
            // txtLocalFEM
            // 
            this.txtLocalFEM.Location = new System.Drawing.Point(1110, 191);
            this.txtLocalFEM.Name = "txtLocalFEM";
            this.txtLocalFEM.Size = new System.Drawing.Size(187, 20);
            this.txtLocalFEM.TabIndex = 102;
            // 
            // txtParroFEM
            // 
            this.txtParroFEM.Location = new System.Drawing.Point(1110, 158);
            this.txtParroFEM.Name = "txtParroFEM";
            this.txtParroFEM.Size = new System.Drawing.Size(187, 20);
            this.txtParroFEM.TabIndex = 101;
            // 
            // txtCantonFEM
            // 
            this.txtCantonFEM.Location = new System.Drawing.Point(1110, 130);
            this.txtCantonFEM.Name = "txtCantonFEM";
            this.txtCantonFEM.Size = new System.Drawing.Size(187, 20);
            this.txtCantonFEM.TabIndex = 100;
            // 
            // txtProvFEM
            // 
            this.txtProvFEM.Location = new System.Drawing.Point(1110, 95);
            this.txtProvFEM.Name = "txtProvFEM";
            this.txtProvFEM.Size = new System.Drawing.Size(187, 20);
            this.txtProvFEM.TabIndex = 99;
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(985, 194);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 13);
            this.label37.TabIndex = 98;
            this.label37.Text = "Localidad";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(984, 161);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(120, 13);
            this.label36.TabIndex = 97;
            this.label36.Text = "Parroquia urbano o rural";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(985, 133);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 96;
            this.label35.Text = "Cantón";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(985, 98);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(51, 13);
            this.label34.TabIndex = 95;
            this.label34.Text = "Provincia";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(985, 71);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(236, 13);
            this.label33.TabIndex = 94;
            this.label33.Text = "RESIDENCIA HABITUAL DEL CONTRAYENTE";
            // 
            // cmbInstrucFEM
            // 
            this.cmbInstrucFEM.FormattingEnabled = true;
            this.cmbInstrucFEM.Items.AddRange(new object[] {
            "Ninguno",
            "Centro de alfabetización",
            "Primaria",
            "Secundaria",
            "Educación básica",
            "Educación media/bachillerato",
            "Ciclo posbachillerato",
            "Superior",
            "Posgrado"});
            this.cmbInstrucFEM.Location = new System.Drawing.Point(727, 270);
            this.cmbInstrucFEM.Name = "cmbInstrucFEM";
            this.cmbInstrucFEM.Size = new System.Drawing.Size(198, 21);
            this.cmbInstrucFEM.TabIndex = 93;
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(724, 242);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(201, 13);
            this.label32.TabIndex = 92;
            this.label32.Text = "NIVEL DE INSTRUCCIÓN ALCANZADO";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(724, 161);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(144, 13);
            this.label31.TabIndex = 90;
            this.label31.Text = "¿ SABE LEER Y ESCRIBIR?";
            // 
            // cmbEtniaFEM
            // 
            this.cmbEtniaFEM.FormattingEnabled = true;
            this.cmbEtniaFEM.Items.AddRange(new object[] {
            "Indígena",
            "Afroecuatoriano/Afrodescendiente",
            "Negro",
            "Mulato",
            "Montubio",
            "Mestizo",
            "Blanco",
            "Otro"});
            this.cmbEtniaFEM.Location = new System.Drawing.Point(467, 253);
            this.cmbEtniaFEM.Name = "cmbEtniaFEM";
            this.cmbEtniaFEM.Size = new System.Drawing.Size(191, 21);
            this.cmbEtniaFEM.TabIndex = 89;
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(464, 223);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(119, 13);
            this.label30.TabIndex = 88;
            this.label30.Text = "identifica el contrayente";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(464, 210);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(192, 13);
            this.label29.TabIndex = 87;
            this.label29.Text = "Según la cultura y costumbres cómo se";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(464, 187);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(88, 13);
            this.label28.TabIndex = 86;
            this.label28.Text = "CONTRAYENTE";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(464, 174);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(80, 13);
            this.label27.TabIndex = 85;
            this.label27.Text = "ÉTNICA DE LA";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(464, 161);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(122, 13);
            this.label26.TabIndex = 84;
            this.label26.Text = "AUTOIDENTIFICACIÓN";
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(288, 161);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(142, 13);
            this.label25.TabIndex = 82;
            this.label25.Text = "ESTADO CIVIL ANTERIOR:";
            // 
            // txtDniFEM
            // 
            this.txtDniFEM.Location = new System.Drawing.Point(20, 184);
            this.txtDniFEM.Name = "txtDniFEM";
            this.txtDniFEM.Size = new System.Drawing.Size(246, 20);
            this.txtDniFEM.TabIndex = 81;
            this.txtDniFEM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDniFEM_KeyPress);
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(17, 158);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(236, 13);
            this.label24.TabIndex = 80;
            this.label24.Text = "No. CÉDULA DE CIUDADANÍA O PASAPORTE";
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(724, 121);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 13);
            this.label23.TabIndex = 79;
            this.label23.Text = "Código del país";
            // 
            // txtINECExtFEM
            // 
            this.txtINECExtFEM.Location = new System.Drawing.Point(727, 98);
            this.txtINECExtFEM.Name = "txtINECExtFEM";
            this.txtINECExtFEM.Size = new System.Drawing.Size(62, 20);
            this.txtINECExtFEM.TabIndex = 78;
            this.txtINECExtFEM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtINECExtFEM_KeyPress);
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(724, 71);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 13);
            this.label22.TabIndex = 77;
            this.label22.Text = "USO INEC";
            // 
            // txtPaisFEM
            // 
            this.txtPaisFEM.Location = new System.Drawing.Point(465, 98);
            this.txtPaisFEM.Name = "txtPaisFEM";
            this.txtPaisFEM.Size = new System.Drawing.Size(191, 20);
            this.txtPaisFEM.TabIndex = 76;
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(520, 121);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 13);
            this.label21.TabIndex = 75;
            this.label21.Text = "Nombre del país";
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(288, 71);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 13);
            this.label20.TabIndex = 73;
            this.label20.Text = "NACIONALIDAD";
            // 
            // txtNombreFEM
            // 
            this.txtNombreFEM.Location = new System.Drawing.Point(20, 98);
            this.txtNombreFEM.Name = "txtNombreFEM";
            this.txtNombreFEM.Size = new System.Drawing.Size(246, 20);
            this.txtNombreFEM.TabIndex = 72;
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(17, 71);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(133, 13);
            this.label19.TabIndex = 71;
            this.label19.Text = "NOMBRES Y APELLIDOS";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(597, 18);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(162, 13);
            this.label18.TabIndex = 70;
            this.label18.Text = "DATOS DE LA CONTRAYENTE";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(17, 433);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(304, 13);
            this.label1.TabIndex = 112;
            this.label1.Text = "Funcionario responsable del Registro Civil (nombres y apellidos)";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(17, 504);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(112, 13);
            this.label2.TabIndex = 113;
            this.label2.Text = "Cédula de ciudadanía";
            // 
            // txtNombreRespCUE
            // 
            this.txtNombreRespCUE.Location = new System.Drawing.Point(20, 458);
            this.txtNombreRespCUE.Name = "txtNombreRespCUE";
            this.txtNombreRespCUE.Size = new System.Drawing.Size(301, 20);
            this.txtNombreRespCUE.TabIndex = 114;
            // 
            // txtCedulaRespCUE
            // 
            this.txtCedulaRespCUE.Location = new System.Drawing.Point(20, 530);
            this.txtCedulaRespCUE.Name = "txtCedulaRespCUE";
            this.txtCedulaRespCUE.Size = new System.Drawing.Size(301, 20);
            this.txtCedulaRespCUE.TabIndex = 115;
            this.txtCedulaRespCUE.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtCedulaRespCUE_KeyPress);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(360, 433);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(617, 13);
            this.label3.TabIndex = 116;
            this.label3.Text = "Observaciones: Este espacio está destinado para que se pueda anotar cualquier com" +
    "entario que sirva para clarificar algún dato o";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(360, 446);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(199, 13);
            this.label4.TabIndex = 117;
            this.label4.Text = "circunstancia sobre el matrimonio inscrito";
            // 
            // txtObsCUE
            // 
            this.txtObsCUE.Location = new System.Drawing.Point(363, 476);
            this.txtObsCUE.Name = "txtObsCUE";
            this.txtObsCUE.Size = new System.Drawing.Size(614, 20);
            this.txtObsCUE.TabIndex = 118;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(1107, 433);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(58, 13);
            this.label5.TabIndex = 119;
            this.label5.Text = "USO INEC";
            // 
            // txtUInecCUER
            // 
            this.txtUInecCUER.Location = new System.Drawing.Point(1086, 458);
            this.txtUInecCUER.Name = "txtUInecCUER";
            this.txtUInecCUER.Size = new System.Drawing.Size(100, 20);
            this.txtUInecCUER.TabIndex = 120;
            this.txtUInecCUER.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUInecCUER_KeyPress);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(1073, 483);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(134, 13);
            this.label6.TabIndex = 121;
            this.label6.Text = "Código crítico - codificador";
            // 
            // btnRegistrar
            // 
            this.btnRegistrar.Location = new System.Drawing.Point(1066, 555);
            this.btnRegistrar.Name = "btnRegistrar";
            this.btnRegistrar.Size = new System.Drawing.Size(155, 23);
            this.btnRegistrar.TabIndex = 122;
            this.btnRegistrar.Text = "REGISTRAR FORMULARIO";
            this.btnRegistrar.UseVisualStyleBackColor = true;
            this.btnRegistrar.Click += new System.EventHandler(this.btnRegistrar_Click);
            // 
            // txtEdadFEM
            // 
            this.txtEdadFEM.Location = new System.Drawing.Point(20, 334);
            this.txtEdadFEM.Name = "txtEdadFEM";
            this.txtEdadFEM.Size = new System.Drawing.Size(100, 20);
            this.txtEdadFEM.TabIndex = 123;
            this.txtEdadFEM.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEdadFEM_KeyPress);
            // 
            // cmbLeerFEM
            // 
            this.cmbLeerFEM.FormattingEnabled = true;
            this.cmbLeerFEM.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cmbLeerFEM.Location = new System.Drawing.Point(727, 187);
            this.cmbLeerFEM.Name = "cmbLeerFEM";
            this.cmbLeerFEM.Size = new System.Drawing.Size(121, 21);
            this.cmbLeerFEM.TabIndex = 126;
            // 
            // cmbEstCivilFEM
            // 
            this.cmbEstCivilFEM.FormattingEnabled = true;
            this.cmbEstCivilFEM.Items.AddRange(new object[] {
            "Soltera",
            "Divorciada",
            "Vuida"});
            this.cmbEstCivilFEM.Location = new System.Drawing.Point(291, 184);
            this.cmbEstCivilFEM.Name = "cmbEstCivilFEM";
            this.cmbEstCivilFEM.Size = new System.Drawing.Size(139, 21);
            this.cmbEstCivilFEM.TabIndex = 125;
            // 
            // cmbNacionFEM
            // 
            this.cmbNacionFEM.FormattingEnabled = true;
            this.cmbNacionFEM.Items.AddRange(new object[] {
            "Ecuatoriana",
            "Extranjera"});
            this.cmbNacionFEM.Location = new System.Drawing.Point(291, 98);
            this.cmbNacionFEM.Name = "cmbNacionFEM";
            this.cmbNacionFEM.Size = new System.Drawing.Size(139, 21);
            this.cmbNacionFEM.TabIndex = 124;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(924, 555);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 127;
            this.button1.Text = "SALIR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // FrmFormularioP2
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(1310, 611);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.cmbLeerFEM);
            this.Controls.Add(this.cmbEstCivilFEM);
            this.Controls.Add(this.cmbNacionFEM);
            this.Controls.Add(this.txtEdadFEM);
            this.Controls.Add(this.btnRegistrar);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.txtUInecCUER);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.txtObsCUE);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.txtCedulaRespCUE);
            this.Controls.Add(this.txtNombreRespCUE);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.txtNumMatriFEM);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.dateFechaNacFEM);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.txtUInecFEM);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.txtLocalFEM);
            this.Controls.Add(this.txtParroFEM);
            this.Controls.Add(this.txtCantonFEM);
            this.Controls.Add(this.txtProvFEM);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.cmbInstrucFEM);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.cmbEtniaFEM);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtDniFEM);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtINECExtFEM);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtPaisFEM);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtNombreFEM);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Name = "FrmFormularioP2";
            this.Text = "FormularioMatrimonio";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtNumMatriFEM;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.DateTimePicker dateFechaNacFEM;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.TextBox txtUInecFEM;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtLocalFEM;
        private System.Windows.Forms.TextBox txtParroFEM;
        private System.Windows.Forms.TextBox txtCantonFEM;
        private System.Windows.Forms.TextBox txtProvFEM;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.ComboBox cmbInstrucFEM;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.ComboBox cmbEtniaFEM;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.TextBox txtDniFEM;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.TextBox txtINECExtFEM;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtPaisFEM;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.TextBox txtNombreFEM;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.TextBox txtNombreRespCUE;
        private System.Windows.Forms.TextBox txtCedulaRespCUE;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtObsCUE;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtUInecCUER;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btnRegistrar;
        private System.Windows.Forms.TextBox txtEdadFEM;
        private System.Windows.Forms.ComboBox cmbLeerFEM;
        private System.Windows.Forms.ComboBox cmbEstCivilFEM;
        private System.Windows.Forms.ComboBox cmbNacionFEM;
        private System.Windows.Forms.Button button1;
    }
}