﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectoMatrimonio
{
    public partial class FrmFormularioP2 : Form
    {

        public String NombreOficina = "";
        public String ProvinciaCAB = "";
        public String CantonCAB = "";
        public String ParroCAB = "";
        public String FechaMatriCAB = "";
        public int UInecCAB = 0;
        public int NumOficinaCAB = 0;
        public String FechaInecCAB = "";
        public int NumActaCAB = 0;
        public int NumHijosCAB = 0;
        public String CBienesCAB = "";
        public String NombreMASC = "";
        public String NacionMASC = "";
        public String PaisExtMASC = "";
        public int INECExtMASC = 0;
        public int DniMASC = 0;
        public String EstCivilMASC = "";
        public String EtniaMASC = "";
        public String LeerMASC = "";
        public String InstrucMASC = "";
        public String ProvMASC = "";
        public String CantonMASC = "";
        public String ParroMASC = "";
        public String LocalMASC = "";
        public int UInecMASC = 0;
        public String FechaNacimientoMASC = "";
        public int NumeroMatriMASC = 0;
        public int EdadMASC = 0;

        public FrmFormularioP2()
        {
            InitializeComponent();

            Bitmap img = new Bitmap(Application.StartupPath + @"\imagen\imagen4.jpg");
            this.BackgroundImage = img;
            this.BackgroundImageLayout = ImageLayout.Stretch;

        }

        private void btnRegistrar_Click(object sender, EventArgs e)
        {
            int idOfic = 2000;
            int idCab = 1;
            int idCue = 1000;
            int INECExtFEM = 0;
            String PaisExtFEM = "";

            Conexion c = new Conexion();


            String sText = txtDniFEM.Text;

            if (sText.Length > 10)
            {
                MessageBox.Show("Error");
            }

            else
            {
                if (string.IsNullOrEmpty(txtCantonFEM.Text) || string.IsNullOrEmpty(txtCedulaRespCUE.Text) || string.IsNullOrEmpty(txtDniFEM.Text) || string.IsNullOrEmpty(txtEdadFEM.Text) || string.IsNullOrEmpty(txtLocalFEM.Text) || string.IsNullOrEmpty(txtNombreFEM.Text) || string.IsNullOrEmpty(txtNombreRespCUE.Text) || string.IsNullOrEmpty(txtNumMatriFEM.Text) || string.IsNullOrEmpty(txtObsCUE.Text) || string.IsNullOrEmpty(txtParroFEM.Text) || string.IsNullOrEmpty(txtProvFEM.Text) || string.IsNullOrEmpty(txtUInecCUER.Text) || string.IsNullOrEmpty(txtUInecFEM.Text))
                {

                    MessageBox.Show("Se tiene que completar toda la informacion");


                }
                else
                {
                    String NombreFEM = txtNombreFEM.Text;
                    String NacionFEM = cmbNacionFEM.Text;

                    if (string.IsNullOrEmpty(txtPaisFEM.Text))
                    {

                        PaisExtFEM = "Ecuador";


                    }
                    else
                    {
                        PaisExtFEM = txtPaisFEM.Text;
                    }


                    if (string.IsNullOrEmpty(txtINECExtFEM.Text))
                    {

                        INECExtFEM = 0;


                    }
                    else
                    {
                        INECExtFEM = int.Parse(txtINECExtFEM.Text);
                    }


                    int DniFEM = int.Parse(txtDniFEM.Text);
                    String EstCivilFEM = cmbEstCivilFEM.Text;
                    String EtniaFEM = cmbEtniaFEM.Text;
                    String LeerFEM = cmbLeerFEM.Text;
                    String InstrucFEM = cmbInstrucFEM.Text;
                    String ProvFEM = txtProvFEM.Text;
                    String CantonFEM = txtCantonFEM.Text;
                    String ParroFEM = txtParroFEM.Text;
                    String LocalFEM = txtLocalFEM.Text;
                    int UInecFEM = int.Parse(txtUInecFEM.Text);
                    String FechaNacimientoFEM = dateFechaNacFEM.Text;
                    int NumeroMatriFEM = int.Parse(txtNumMatriFEM.Text);
                    int EdadFEM = int.Parse(txtEdadFEM.Text);
                    String NombreResponsable = txtNombreRespCUE.Text;
                    int CedulaResp = int.Parse(txtCedulaRespCUE.Text);
                    String observacion = txtObsCUE.Text;
                    int INECCuerpo = int.Parse(txtUInecCUER.Text);


                    c.insertarREGISTRO_CIVIL(idOfic, NombreOficina, NumOficinaCAB, ProvinciaCAB, CantonCAB, ParroCAB);

                    c.insertarCABECERA_FORMULARIO(idCue, idOfic, FechaMatriCAB, UInecCAB, FechaInecCAB, NumActaCAB, NumHijosCAB, CBienesCAB);

                    c.insertarCONTRAYENTE_MASC(DniMASC, idCue, NombreMASC, FechaNacimientoMASC, EdadMASC, NumeroMatriMASC, NacionMASC, PaisExtMASC, INECExtMASC, EstCivilMASC, EtniaMASC, LeerMASC, InstrucMASC, ProvMASC, CantonMASC, ParroMASC, LocalMASC, UInecMASC);

                    c.insertarCUERPO_FORMULARIO(CedulaResp, DniMASC, idCab, DniFEM, INECCuerpo, observacion);

                    c.insertarRESPONSABLE(CedulaResp, idCue, NombreResponsable);

                    c.insertarCONTRAYENTE_FEM(DniFEM, idCue, NombreFEM, FechaNacimientoFEM, EdadFEM, NumeroMatriFEM, NacionFEM, PaisExtFEM, INECExtFEM, EstCivilFEM, EtniaFEM, LeerFEM, InstrucFEM, ProvFEM, CantonFEM, ParroFEM, LocalFEM, UInecFEM);

                }



                idOfic++;
                idCab++;
                idCue++;
            }
        }







        private void txtDniFEM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtEdadFEM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtINECExtFEM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtUInecFEM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtNumMatriFEM_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtCedulaRespCUE_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtUInecCUER_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmLogin forml = new FrmLogin();
            forml.Show();
            this.Close();
        }
    }
}
