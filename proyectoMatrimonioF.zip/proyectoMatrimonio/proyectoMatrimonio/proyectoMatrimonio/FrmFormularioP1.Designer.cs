﻿namespace proyectoMatrimonio
{
    partial class FrmFormularioP1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtNombreOficina = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.txtProvinciaCAB = new System.Windows.Forms.TextBox();
            this.txtCantonCAB = new System.Windows.Forms.TextBox();
            this.txtParroCAB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.dateFechaMatriCAB = new System.Windows.Forms.DateTimePicker();
            this.label8 = new System.Windows.Forms.Label();
            this.txtUInecCAB = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txtNumOficinaCAB = new System.Windows.Forms.TextBox();
            this.label10 = new System.Windows.Forms.Label();
            this.dateFechaInecCAB = new System.Windows.Forms.DateTimePicker();
            this.label11 = new System.Windows.Forms.Label();
            this.txtNumActaCAB = new System.Windows.Forms.TextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.txtNumHijosCAB = new System.Windows.Forms.TextBox();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.label15 = new System.Windows.Forms.Label();
            this.label16 = new System.Windows.Forms.Label();
            this.label17 = new System.Windows.Forms.Label();
            this.label18 = new System.Windows.Forms.Label();
            this.label19 = new System.Windows.Forms.Label();
            this.txtNombreMASC = new System.Windows.Forms.TextBox();
            this.label20 = new System.Windows.Forms.Label();
            this.label21 = new System.Windows.Forms.Label();
            this.txtPaisExtMASC = new System.Windows.Forms.TextBox();
            this.label22 = new System.Windows.Forms.Label();
            this.txtINECExtMASC = new System.Windows.Forms.TextBox();
            this.label23 = new System.Windows.Forms.Label();
            this.label24 = new System.Windows.Forms.Label();
            this.txtDniMASC = new System.Windows.Forms.TextBox();
            this.label25 = new System.Windows.Forms.Label();
            this.label26 = new System.Windows.Forms.Label();
            this.label27 = new System.Windows.Forms.Label();
            this.label28 = new System.Windows.Forms.Label();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.cmbEtniaMASC = new System.Windows.Forms.ComboBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.cmbInstrucMASC = new System.Windows.Forms.ComboBox();
            this.label33 = new System.Windows.Forms.Label();
            this.label34 = new System.Windows.Forms.Label();
            this.label35 = new System.Windows.Forms.Label();
            this.label36 = new System.Windows.Forms.Label();
            this.label37 = new System.Windows.Forms.Label();
            this.txtProvMASC = new System.Windows.Forms.TextBox();
            this.txtCantonMASC = new System.Windows.Forms.TextBox();
            this.txtParroMASC = new System.Windows.Forms.TextBox();
            this.txtLocalMASC = new System.Windows.Forms.TextBox();
            this.label38 = new System.Windows.Forms.Label();
            this.txtUInecMASC = new System.Windows.Forms.TextBox();
            this.label39 = new System.Windows.Forms.Label();
            this.dateFechaNacMASC = new System.Windows.Forms.DateTimePicker();
            this.label40 = new System.Windows.Forms.Label();
            this.label41 = new System.Windows.Forms.Label();
            this.label42 = new System.Windows.Forms.Label();
            this.txtNumMatriMASC = new System.Windows.Forms.TextBox();
            this.btnSiguiente = new System.Windows.Forms.Button();
            this.txtEdadMASC = new System.Windows.Forms.TextBox();
            this.cmbCBienesCAB = new System.Windows.Forms.ComboBox();
            this.cmbNacionMASC = new System.Windows.Forms.ComboBox();
            this.cmbEstCivilMASC = new System.Windows.Forms.ComboBox();
            this.cmbLeerMASC = new System.Windows.Forms.ComboBox();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(495, 23);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(147, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "RÉPUBLICA DEL ECUADOR";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(482, 49);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(169, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "FORMULARIO DE MATRIMONIO";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 95);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(176, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "OFICINA DE REGISTRO CIVIL DE:";
            // 
            // txtNombreOficina
            // 
            this.txtNombreOficina.Location = new System.Drawing.Point(194, 92);
            this.txtNombreOficina.Name = "txtNombreOficina";
            this.txtNombreOficina.Size = new System.Drawing.Size(335, 20);
            this.txtNombreOficina.TabIndex = 3;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(12, 133);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(68, 13);
            this.label4.TabIndex = 4;
            this.label4.Text = "PROVINCIA:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(12, 170);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(55, 13);
            this.label5.TabIndex = 5;
            this.label5.Text = "CANTÓN:";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 200);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(173, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "PARROQUIA URBANA O RURAL:";
            // 
            // txtProvinciaCAB
            // 
            this.txtProvinciaCAB.Location = new System.Drawing.Point(194, 130);
            this.txtProvinciaCAB.Name = "txtProvinciaCAB";
            this.txtProvinciaCAB.Size = new System.Drawing.Size(335, 20);
            this.txtProvinciaCAB.TabIndex = 7;
            // 
            // txtCantonCAB
            // 
            this.txtCantonCAB.Location = new System.Drawing.Point(194, 167);
            this.txtCantonCAB.Name = "txtCantonCAB";
            this.txtCantonCAB.Size = new System.Drawing.Size(335, 20);
            this.txtCantonCAB.TabIndex = 8;
            // 
            // txtParroCAB
            // 
            this.txtParroCAB.Location = new System.Drawing.Point(194, 197);
            this.txtParroCAB.Name = "txtParroCAB";
            this.txtParroCAB.Size = new System.Drawing.Size(335, 20);
            this.txtParroCAB.TabIndex = 9;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(12, 235);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(136, 13);
            this.label7.TabIndex = 10;
            this.label7.Text = "FECHA DE MATRIMONIO:";
            // 
            // dateFechaMatriCAB
            // 
            this.dateFechaMatriCAB.Location = new System.Drawing.Point(194, 229);
            this.dateFechaMatriCAB.Name = "dateFechaMatriCAB";
            this.dateFechaMatriCAB.Size = new System.Drawing.Size(335, 20);
            this.dateFechaMatriCAB.TabIndex = 11;
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(596, 92);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(58, 13);
            this.label8.TabIndex = 12;
            this.label8.Text = "USO INEC";
            // 
            // txtUInecCAB
            // 
            this.txtUInecCAB.Location = new System.Drawing.Point(599, 126);
            this.txtUInecCAB.Name = "txtUInecCAB";
            this.txtUInecCAB.Size = new System.Drawing.Size(100, 20);
            this.txtUInecCAB.TabIndex = 13;
            this.txtUInecCAB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUInecCAB_KeyPress);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(991, 95);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(59, 13);
            this.label9.TabIndex = 14;
            this.label9.Text = "OFICINA #";
            // 
            // txtNumOficinaCAB
            // 
            this.txtNumOficinaCAB.Location = new System.Drawing.Point(994, 122);
            this.txtNumOficinaCAB.Name = "txtNumOficinaCAB";
            this.txtNumOficinaCAB.Size = new System.Drawing.Size(56, 20);
            this.txtNumOficinaCAB.TabIndex = 15;
            this.txtNumOficinaCAB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumOficinaCAB_KeyPress);
            this.txtNumOficinaCAB.KeyUp += new System.Windows.Forms.KeyEventHandler(this.txtNumOficinaCAB_KeyUp);
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(1075, 95);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(141, 13);
            this.label10.TabIndex = 16;
            this.label10.Text = "USO INEC FECHA CRÍTICA";
            // 
            // dateFechaInecCAB
            // 
            this.dateFechaInecCAB.Location = new System.Drawing.Point(1078, 122);
            this.dateFechaInecCAB.Name = "dateFechaInecCAB";
            this.dateFechaInecCAB.Size = new System.Drawing.Size(200, 20);
            this.dateFechaInecCAB.TabIndex = 17;
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(596, 177);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(128, 13);
            this.label11.TabIndex = 18;
            this.label11.Text = "ACTA DE INSCRIPCIÓN:";
            // 
            // txtNumActaCAB
            // 
            this.txtNumActaCAB.Location = new System.Drawing.Point(748, 174);
            this.txtNumActaCAB.Name = "txtNumActaCAB";
            this.txtNumActaCAB.Size = new System.Drawing.Size(285, 20);
            this.txtNumActaCAB.TabIndex = 19;
            this.txtNumActaCAB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumActaCAB_KeyPress);
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Location = new System.Drawing.Point(596, 223);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(107, 13);
            this.label12.TabIndex = 20;
            this.label12.Text = "NÚMERO DE HIJOS";
            // 
            // txtNumHijosCAB
            // 
            this.txtNumHijosCAB.Location = new System.Drawing.Point(743, 233);
            this.txtNumHijosCAB.Name = "txtNumHijosCAB";
            this.txtNumHijosCAB.Size = new System.Drawing.Size(47, 20);
            this.txtNumHijosCAB.TabIndex = 21;
            this.txtNumHijosCAB.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumHijosCAB_KeyPress);
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Location = new System.Drawing.Point(596, 236);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(128, 13);
            this.label13.TabIndex = 22;
            this.label13.Text = "RECONOCIDOS POR EL";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Location = new System.Drawing.Point(596, 249);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(141, 13);
            this.label14.TabIndex = 23;
            this.label14.Text = "PRESENTE MATRIMONIO:";
            // 
            // label15
            // 
            this.label15.AutoSize = true;
            this.label15.Location = new System.Drawing.Point(991, 223);
            this.label15.Name = "label15";
            this.label15.Size = new System.Drawing.Size(103, 13);
            this.label15.TabIndex = 24;
            this.label15.Text = "MATRIMONIO CON";
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Location = new System.Drawing.Point(991, 236);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(103, 13);
            this.label16.TabIndex = 25;
            this.label16.Text = "CAPITULACIÓN DE";
            // 
            // label17
            // 
            this.label17.AutoSize = true;
            this.label17.Location = new System.Drawing.Point(991, 249);
            this.label17.Name = "label17";
            this.label17.Size = new System.Drawing.Size(49, 13);
            this.label17.TabIndex = 26;
            this.label17.Text = "BIENES:";
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(495, 302);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(152, 13);
            this.label18.TabIndex = 28;
            this.label18.Text = "DATOS DEL CONTRAYENTE";
            // 
            // label19
            // 
            this.label19.AutoSize = true;
            this.label19.Location = new System.Drawing.Point(12, 343);
            this.label19.Name = "label19";
            this.label19.Size = new System.Drawing.Size(133, 13);
            this.label19.TabIndex = 29;
            this.label19.Text = "NOMBRES Y APELLIDOS";
            // 
            // txtNombreMASC
            // 
            this.txtNombreMASC.Location = new System.Drawing.Point(15, 370);
            this.txtNombreMASC.Name = "txtNombreMASC";
            this.txtNombreMASC.Size = new System.Drawing.Size(246, 20);
            this.txtNombreMASC.TabIndex = 30;
            // 
            // label20
            // 
            this.label20.AutoSize = true;
            this.label20.Location = new System.Drawing.Point(283, 343);
            this.label20.Name = "label20";
            this.label20.Size = new System.Drawing.Size(87, 13);
            this.label20.TabIndex = 31;
            this.label20.Text = "NACIONALIDAD";
            // 
            // label21
            // 
            this.label21.AutoSize = true;
            this.label21.Location = new System.Drawing.Point(515, 393);
            this.label21.Name = "label21";
            this.label21.Size = new System.Drawing.Size(85, 13);
            this.label21.TabIndex = 33;
            this.label21.Text = "Nombre del país";
            // 
            // txtPaisExtMASC
            // 
            this.txtPaisExtMASC.Location = new System.Drawing.Point(460, 370);
            this.txtPaisExtMASC.Name = "txtPaisExtMASC";
            this.txtPaisExtMASC.Size = new System.Drawing.Size(191, 20);
            this.txtPaisExtMASC.TabIndex = 34;
            // 
            // label22
            // 
            this.label22.AutoSize = true;
            this.label22.Location = new System.Drawing.Point(719, 343);
            this.label22.Name = "label22";
            this.label22.Size = new System.Drawing.Size(58, 13);
            this.label22.TabIndex = 35;
            this.label22.Text = "USO INEC";
            // 
            // txtINECExtMASC
            // 
            this.txtINECExtMASC.Location = new System.Drawing.Point(722, 370);
            this.txtINECExtMASC.Name = "txtINECExtMASC";
            this.txtINECExtMASC.Size = new System.Drawing.Size(62, 20);
            this.txtINECExtMASC.TabIndex = 36;
            this.txtINECExtMASC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtINECExtMASC_KeyPress);
            // 
            // label23
            // 
            this.label23.AutoSize = true;
            this.label23.Location = new System.Drawing.Point(719, 393);
            this.label23.Name = "label23";
            this.label23.Size = new System.Drawing.Size(81, 13);
            this.label23.TabIndex = 37;
            this.label23.Text = "Código del país";
            // 
            // label24
            // 
            this.label24.AutoSize = true;
            this.label24.Location = new System.Drawing.Point(12, 430);
            this.label24.Name = "label24";
            this.label24.Size = new System.Drawing.Size(236, 13);
            this.label24.TabIndex = 38;
            this.label24.Text = "No. CÉDULA DE CIUDADANÍA O PASAPORTE";
            // 
            // txtDniMASC
            // 
            this.txtDniMASC.Location = new System.Drawing.Point(15, 456);
            this.txtDniMASC.Name = "txtDniMASC";
            this.txtDniMASC.Size = new System.Drawing.Size(246, 20);
            this.txtDniMASC.TabIndex = 39;
            this.txtDniMASC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDniMASC_KeyPress);
            // 
            // label25
            // 
            this.label25.AutoSize = true;
            this.label25.Location = new System.Drawing.Point(283, 433);
            this.label25.Name = "label25";
            this.label25.Size = new System.Drawing.Size(142, 13);
            this.label25.TabIndex = 40;
            this.label25.Text = "ESTADO CIVIL ANTERIOR:";
            // 
            // label26
            // 
            this.label26.AutoSize = true;
            this.label26.Location = new System.Drawing.Point(459, 433);
            this.label26.Name = "label26";
            this.label26.Size = new System.Drawing.Size(122, 13);
            this.label26.TabIndex = 42;
            this.label26.Text = "AUTOIDENTIFICACIÓN";
            // 
            // label27
            // 
            this.label27.AutoSize = true;
            this.label27.Location = new System.Drawing.Point(459, 446);
            this.label27.Name = "label27";
            this.label27.Size = new System.Drawing.Size(70, 13);
            this.label27.TabIndex = 43;
            this.label27.Text = "ÉTNICA DEL";
            // 
            // label28
            // 
            this.label28.AutoSize = true;
            this.label28.Location = new System.Drawing.Point(459, 459);
            this.label28.Name = "label28";
            this.label28.Size = new System.Drawing.Size(88, 13);
            this.label28.TabIndex = 44;
            this.label28.Text = "CONTRAYENTE";
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Location = new System.Drawing.Point(459, 482);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(192, 13);
            this.label29.TabIndex = 45;
            this.label29.Text = "Según la cultura y costumbres cómo se";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Location = new System.Drawing.Point(459, 495);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(119, 13);
            this.label30.TabIndex = 46;
            this.label30.Text = "identifica el contrayente";
            // 
            // cmbEtniaMASC
            // 
            this.cmbEtniaMASC.FormattingEnabled = true;
            this.cmbEtniaMASC.Items.AddRange(new object[] {
            "Indígena",
            "Afroecuatoriano/Afrodescendiente",
            "Negro",
            "Mulato",
            "Montubio",
            "Mestizo",
            "Blanco",
            "Otro"});
            this.cmbEtniaMASC.Location = new System.Drawing.Point(462, 525);
            this.cmbEtniaMASC.Name = "cmbEtniaMASC";
            this.cmbEtniaMASC.Size = new System.Drawing.Size(191, 21);
            this.cmbEtniaMASC.TabIndex = 47;
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Location = new System.Drawing.Point(719, 433);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(144, 13);
            this.label31.TabIndex = 48;
            this.label31.Text = "¿ SABE LEER Y ESCRIBIR?";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Location = new System.Drawing.Point(719, 514);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(201, 13);
            this.label32.TabIndex = 50;
            this.label32.Text = "NIVEL DE INSTRUCCIÓN ALCANZADO";
            // 
            // cmbInstrucMASC
            // 
            this.cmbInstrucMASC.FormattingEnabled = true;
            this.cmbInstrucMASC.Items.AddRange(new object[] {
            "Ninguno",
            "Centro de alfabetización",
            "Primaria",
            "Secundaria",
            "Educación básica",
            "Educación media/bachillerato",
            "Ciclo posbachillerato",
            "Superior",
            "Posgrado"});
            this.cmbInstrucMASC.Location = new System.Drawing.Point(722, 542);
            this.cmbInstrucMASC.Name = "cmbInstrucMASC";
            this.cmbInstrucMASC.Size = new System.Drawing.Size(198, 21);
            this.cmbInstrucMASC.TabIndex = 51;
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Location = new System.Drawing.Point(980, 343);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(236, 13);
            this.label33.TabIndex = 52;
            this.label33.Text = "RESIDENCIA HABITUAL DEL CONTRAYENTE";
            // 
            // label34
            // 
            this.label34.AutoSize = true;
            this.label34.Location = new System.Drawing.Point(980, 370);
            this.label34.Name = "label34";
            this.label34.Size = new System.Drawing.Size(51, 13);
            this.label34.TabIndex = 53;
            this.label34.Text = "Provincia";
            // 
            // label35
            // 
            this.label35.AutoSize = true;
            this.label35.Location = new System.Drawing.Point(980, 405);
            this.label35.Name = "label35";
            this.label35.Size = new System.Drawing.Size(41, 13);
            this.label35.TabIndex = 54;
            this.label35.Text = "Cantón";
            // 
            // label36
            // 
            this.label36.AutoSize = true;
            this.label36.Location = new System.Drawing.Point(979, 433);
            this.label36.Name = "label36";
            this.label36.Size = new System.Drawing.Size(120, 13);
            this.label36.TabIndex = 55;
            this.label36.Text = "Parroquia urbano o rural";
            // 
            // label37
            // 
            this.label37.AutoSize = true;
            this.label37.Location = new System.Drawing.Point(980, 466);
            this.label37.Name = "label37";
            this.label37.Size = new System.Drawing.Size(53, 13);
            this.label37.TabIndex = 56;
            this.label37.Text = "Localidad";
            // 
            // txtProvMASC
            // 
            this.txtProvMASC.Location = new System.Drawing.Point(1105, 367);
            this.txtProvMASC.Name = "txtProvMASC";
            this.txtProvMASC.Size = new System.Drawing.Size(187, 20);
            this.txtProvMASC.TabIndex = 57;
            // 
            // txtCantonMASC
            // 
            this.txtCantonMASC.Location = new System.Drawing.Point(1105, 402);
            this.txtCantonMASC.Name = "txtCantonMASC";
            this.txtCantonMASC.Size = new System.Drawing.Size(187, 20);
            this.txtCantonMASC.TabIndex = 58;
            // 
            // txtParroMASC
            // 
            this.txtParroMASC.Location = new System.Drawing.Point(1105, 430);
            this.txtParroMASC.Name = "txtParroMASC";
            this.txtParroMASC.Size = new System.Drawing.Size(187, 20);
            this.txtParroMASC.TabIndex = 59;
            // 
            // txtLocalMASC
            // 
            this.txtLocalMASC.Location = new System.Drawing.Point(1105, 463);
            this.txtLocalMASC.Name = "txtLocalMASC";
            this.txtLocalMASC.Size = new System.Drawing.Size(187, 20);
            this.txtLocalMASC.TabIndex = 60;
            // 
            // label38
            // 
            this.label38.AutoSize = true;
            this.label38.Location = new System.Drawing.Point(1102, 514);
            this.label38.Name = "label38";
            this.label38.Size = new System.Drawing.Size(58, 13);
            this.label38.TabIndex = 61;
            this.label38.Text = "USO INEC";
            // 
            // txtUInecMASC
            // 
            this.txtUInecMASC.Location = new System.Drawing.Point(1017, 542);
            this.txtUInecMASC.Name = "txtUInecMASC";
            this.txtUInecMASC.Size = new System.Drawing.Size(233, 20);
            this.txtUInecMASC.TabIndex = 62;
            this.txtUInecMASC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtUInecMASC_KeyPress);
            // 
            // label39
            // 
            this.label39.AutoSize = true;
            this.label39.Location = new System.Drawing.Point(12, 504);
            this.label39.Name = "label39";
            this.label39.Size = new System.Drawing.Size(130, 13);
            this.label39.TabIndex = 63;
            this.label39.Text = "FECHA DE NACIMIENTO";
            // 
            // dateFechaNacMASC
            // 
            this.dateFechaNacMASC.Location = new System.Drawing.Point(15, 525);
            this.dateFechaNacMASC.Name = "dateFechaNacMASC";
            this.dateFechaNacMASC.Size = new System.Drawing.Size(246, 20);
            this.dateFechaNacMASC.TabIndex = 64;
            // 
            // label40
            // 
            this.label40.AutoSize = true;
            this.label40.Location = new System.Drawing.Point(12, 567);
            this.label40.Name = "label40";
            this.label40.Size = new System.Drawing.Size(37, 13);
            this.label40.TabIndex = 65;
            this.label40.Text = "EDAD";
            // 
            // label41
            // 
            this.label41.AutoSize = true;
            this.label41.Location = new System.Drawing.Point(12, 590);
            this.label41.Name = "label41";
            this.label41.Size = new System.Drawing.Size(201, 13);
            this.label41.TabIndex = 66;
            this.label41.Text = "Años cumplidos a la fecha del matrimonio";
            // 
            // label42
            // 
            this.label42.AutoSize = true;
            this.label42.Location = new System.Drawing.Point(355, 567);
            this.label42.Name = "label42";
            this.label42.Size = new System.Drawing.Size(226, 13);
            this.label42.TabIndex = 68;
            this.label42.Text = "NÚMERO DE MATRIMONIOS ANTERIORES";
            // 
            // txtNumMatriMASC
            // 
            this.txtNumMatriMASC.Location = new System.Drawing.Point(358, 590);
            this.txtNumMatriMASC.Name = "txtNumMatriMASC";
            this.txtNumMatriMASC.Size = new System.Drawing.Size(100, 20);
            this.txtNumMatriMASC.TabIndex = 69;
            this.txtNumMatriMASC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtNumMatriMASC_KeyPress);
            // 
            // btnSiguiente
            // 
            this.btnSiguiente.Location = new System.Drawing.Point(1095, 603);
            this.btnSiguiente.Name = "btnSiguiente";
            this.btnSiguiente.Size = new System.Drawing.Size(75, 23);
            this.btnSiguiente.TabIndex = 70;
            this.btnSiguiente.Text = "SIGUIENTE";
            this.btnSiguiente.UseVisualStyleBackColor = true;
            this.btnSiguiente.Click += new System.EventHandler(this.btnSiguiente_Click);
            // 
            // txtEdadMASC
            // 
            this.txtEdadMASC.Location = new System.Drawing.Point(15, 606);
            this.txtEdadMASC.Name = "txtEdadMASC";
            this.txtEdadMASC.Size = new System.Drawing.Size(100, 20);
            this.txtEdadMASC.TabIndex = 71;
            this.txtEdadMASC.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtEdadMASC_KeyPress);
            // 
            // cmbCBienesCAB
            // 
            this.cmbCBienesCAB.FormattingEnabled = true;
            this.cmbCBienesCAB.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cmbCBienesCAB.Location = new System.Drawing.Point(1105, 223);
            this.cmbCBienesCAB.Name = "cmbCBienesCAB";
            this.cmbCBienesCAB.Size = new System.Drawing.Size(121, 21);
            this.cmbCBienesCAB.TabIndex = 72;
            // 
            // cmbNacionMASC
            // 
            this.cmbNacionMASC.FormattingEnabled = true;
            this.cmbNacionMASC.Items.AddRange(new object[] {
            "Ecuatoriano",
            "Extranjero"});
            this.cmbNacionMASC.Location = new System.Drawing.Point(286, 370);
            this.cmbNacionMASC.Name = "cmbNacionMASC";
            this.cmbNacionMASC.Size = new System.Drawing.Size(121, 21);
            this.cmbNacionMASC.TabIndex = 73;
            // 
            // cmbEstCivilMASC
            // 
            this.cmbEstCivilMASC.FormattingEnabled = true;
            this.cmbEstCivilMASC.Items.AddRange(new object[] {
            "Soltero",
            "Divorciado",
            "Viudo"});
            this.cmbEstCivilMASC.Location = new System.Drawing.Point(286, 456);
            this.cmbEstCivilMASC.Name = "cmbEstCivilMASC";
            this.cmbEstCivilMASC.Size = new System.Drawing.Size(139, 21);
            this.cmbEstCivilMASC.TabIndex = 74;
            // 
            // cmbLeerMASC
            // 
            this.cmbLeerMASC.FormattingEnabled = true;
            this.cmbLeerMASC.Items.AddRange(new object[] {
            "Si",
            "No"});
            this.cmbLeerMASC.Location = new System.Drawing.Point(722, 455);
            this.cmbLeerMASC.Name = "cmbLeerMASC";
            this.cmbLeerMASC.Size = new System.Drawing.Size(121, 21);
            this.cmbLeerMASC.TabIndex = 75;
            // 
            // FrmFormularioP1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.AutoScroll = true;
            this.ClientSize = new System.Drawing.Size(1309, 664);
            this.Controls.Add(this.cmbLeerMASC);
            this.Controls.Add(this.cmbEstCivilMASC);
            this.Controls.Add(this.cmbNacionMASC);
            this.Controls.Add(this.cmbCBienesCAB);
            this.Controls.Add(this.txtEdadMASC);
            this.Controls.Add(this.btnSiguiente);
            this.Controls.Add(this.txtNumMatriMASC);
            this.Controls.Add(this.label42);
            this.Controls.Add(this.label41);
            this.Controls.Add(this.label40);
            this.Controls.Add(this.dateFechaNacMASC);
            this.Controls.Add(this.label39);
            this.Controls.Add(this.txtUInecMASC);
            this.Controls.Add(this.label38);
            this.Controls.Add(this.txtLocalMASC);
            this.Controls.Add(this.txtParroMASC);
            this.Controls.Add(this.txtCantonMASC);
            this.Controls.Add(this.txtProvMASC);
            this.Controls.Add(this.label37);
            this.Controls.Add(this.label36);
            this.Controls.Add(this.label35);
            this.Controls.Add(this.label34);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.cmbInstrucMASC);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.cmbEtniaMASC);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.label28);
            this.Controls.Add(this.label27);
            this.Controls.Add(this.label26);
            this.Controls.Add(this.label25);
            this.Controls.Add(this.txtDniMASC);
            this.Controls.Add(this.label24);
            this.Controls.Add(this.label23);
            this.Controls.Add(this.txtINECExtMASC);
            this.Controls.Add(this.label22);
            this.Controls.Add(this.txtPaisExtMASC);
            this.Controls.Add(this.label21);
            this.Controls.Add(this.label20);
            this.Controls.Add(this.txtNombreMASC);
            this.Controls.Add(this.label19);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.label17);
            this.Controls.Add(this.label16);
            this.Controls.Add(this.label15);
            this.Controls.Add(this.label14);
            this.Controls.Add(this.label13);
            this.Controls.Add(this.txtNumHijosCAB);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.txtNumActaCAB);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.dateFechaInecCAB);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.txtNumOficinaCAB);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.txtUInecCAB);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.dateFechaMatriCAB);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.txtParroCAB);
            this.Controls.Add(this.txtCantonCAB);
            this.Controls.Add(this.txtProvinciaCAB);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.txtNombreOficina);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "FrmFormularioP1";
            this.Text = "FormularioMatrimonio";
            this.Load += new System.EventHandler(this.FrmFormulario_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtNombreOficina;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtProvinciaCAB;
        private System.Windows.Forms.TextBox txtCantonCAB;
        private System.Windows.Forms.TextBox txtParroCAB;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.DateTimePicker dateFechaMatriCAB;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txtUInecCAB;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txtNumOficinaCAB;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.DateTimePicker dateFechaInecCAB;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.TextBox txtNumActaCAB;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.TextBox txtNumHijosCAB;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.Label label15;
        private System.Windows.Forms.Label label16;
        private System.Windows.Forms.Label label17;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Label label19;
        private System.Windows.Forms.TextBox txtNombreMASC;
        private System.Windows.Forms.Label label20;
        private System.Windows.Forms.Label label21;
        private System.Windows.Forms.TextBox txtPaisExtMASC;
        private System.Windows.Forms.Label label22;
        private System.Windows.Forms.TextBox txtINECExtMASC;
        private System.Windows.Forms.Label label23;
        private System.Windows.Forms.Label label24;
        private System.Windows.Forms.TextBox txtDniMASC;
        private System.Windows.Forms.Label label25;
        private System.Windows.Forms.Label label26;
        private System.Windows.Forms.Label label27;
        private System.Windows.Forms.Label label28;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.ComboBox cmbEtniaMASC;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.ComboBox cmbInstrucMASC;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Label label34;
        private System.Windows.Forms.Label label35;
        private System.Windows.Forms.Label label36;
        private System.Windows.Forms.Label label37;
        private System.Windows.Forms.TextBox txtProvMASC;
        private System.Windows.Forms.TextBox txtCantonMASC;
        private System.Windows.Forms.TextBox txtParroMASC;
        private System.Windows.Forms.TextBox txtLocalMASC;
        private System.Windows.Forms.Label label38;
        private System.Windows.Forms.TextBox txtUInecMASC;
        private System.Windows.Forms.Label label39;
        private System.Windows.Forms.DateTimePicker dateFechaNacMASC;
        private System.Windows.Forms.Label label40;
        private System.Windows.Forms.Label label41;
        private System.Windows.Forms.Label label42;
        private System.Windows.Forms.TextBox txtNumMatriMASC;
        private System.Windows.Forms.Button btnSiguiente;
        private System.Windows.Forms.TextBox txtEdadMASC;
        private System.Windows.Forms.ComboBox cmbCBienesCAB;
        private System.Windows.Forms.ComboBox cmbNacionMASC;
        private System.Windows.Forms.ComboBox cmbEstCivilMASC;
        private System.Windows.Forms.ComboBox cmbLeerMASC;

    }
}