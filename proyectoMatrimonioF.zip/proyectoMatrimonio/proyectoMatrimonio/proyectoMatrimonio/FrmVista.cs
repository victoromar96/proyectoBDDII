﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

 

namespace proyectoMatrimonio
{

    public partial class FrmVista : Form
    {
        public FrmVista()
        {
            InitializeComponent();

            Bitmap img = new Bitmap(Application.StartupPath + @"\imagen\imagen5.jpg");
            this.BackgroundImage = img;
            this.BackgroundImageLayout = ImageLayout.Stretch;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            FrmLogin fr = new FrmLogin();
            fr.Show();
            this.Hide();
        }

        private void FrmVista_Load(object sender, EventArgs e)
        {
            // TODO: esta línea de código carga datos en la tabla 'proyectoMatrimonioBDDDataSet2.CONTRAYENTE_FEM' Puede moverla o quitarla según sea necesario.
            this.cONTRAYENTE_FEMTableAdapter.Fill(this.proyectoMatrimonioBDDDataSet2.CONTRAYENTE_FEM);
            // TODO: esta línea de código carga datos en la tabla 'proyectoMatrimonioBDDDataSet11.CONTRAYENTE_MASC' Puede moverla o quitarla según sea necesario.
            this.cONTRAYENTE_MASCTableAdapter.Fill(this.proyectoMatrimonioBDDDataSet11.CONTRAYENTE_MASC);
            // TODO: esta línea de código carga datos en la tabla 'proyectoMatrimonioBDDDataSet1.informacion' Puede moverla o quitarla según sea necesario.
            this.informacionTableAdapter.Fill(this.proyectoMatrimonioBDDDataSet1.informacion);

        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
