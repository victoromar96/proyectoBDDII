﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proyectoMatrimonio
{
    public partial class FrmFormularioP1 : Form

    {

        public FrmFormularioP1()
        {
            InitializeComponent();
            Bitmap img = new Bitmap(Application.StartupPath + @"\imagen\imagen4.jpg");
            this.BackgroundImage = img;
            this.BackgroundImageLayout = ImageLayout.Stretch;


        }

        public String recibido;

        private void FrmFormulario_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void btnSiguiente_Click(object sender, EventArgs e)
        {
            String sText = txtDniMASC.Text;

            if (sText.Length > 10)
            {
                MessageBox.Show("Error");
            }

            else
            {
                FrmFormularioP2 form2 = new FrmFormularioP2();



                if (string.IsNullOrEmpty(txtCantonCAB.Text) || string.IsNullOrEmpty(txtCantonMASC.Text) || string.IsNullOrEmpty(txtDniMASC.Text) || string.IsNullOrEmpty(txtEdadMASC.Text) || string.IsNullOrEmpty(txtLocalMASC.Text) || string.IsNullOrEmpty(txtNombreMASC.Text) || string.IsNullOrEmpty(txtNombreOficina.Text) || string.IsNullOrEmpty(txtNumActaCAB.Text) || string.IsNullOrEmpty(txtNumHijosCAB.Text) || string.IsNullOrEmpty(txtNumMatriMASC.Text) || string.IsNullOrEmpty(txtNumOficinaCAB.Text) || string.IsNullOrEmpty(txtParroCAB.Text) || string.IsNullOrEmpty(txtParroMASC.Text) || string.IsNullOrEmpty(txtProvinciaCAB.Text) || string.IsNullOrEmpty(txtProvMASC.Text) || string.IsNullOrEmpty(txtUInecCAB.Text) || string.IsNullOrEmpty(txtUInecMASC.Text))
                {

                    MessageBox.Show("Se tiene que completar toda la informacion");


                }
                else
                {
                    
                    form2.NombreOficina = txtNombreOficina.Text;
                    form2.ProvinciaCAB = txtProvinciaCAB.Text;
                    form2.CantonCAB = txtCantonCAB.Text;
                    form2.ParroCAB = txtParroCAB.Text;
                    form2.FechaMatriCAB = dateFechaMatriCAB.Text;
                    form2.UInecCAB = int.Parse(txtUInecCAB.Text);
                    form2.NumOficinaCAB = int.Parse(txtNumOficinaCAB.Text);
                    form2.FechaInecCAB = dateFechaInecCAB.Text;
                    form2.NumActaCAB = int.Parse(txtNumActaCAB.Text);
                    form2.NumHijosCAB = int.Parse(txtNumHijosCAB.Text);
                    form2.CBienesCAB = cmbCBienesCAB.Text;
                    form2.NombreMASC = txtNombreMASC.Text;
                    form2.NacionMASC = cmbNacionMASC.Text;

                    if (string.IsNullOrEmpty(txtPaisExtMASC.Text))
                    {

                        form2.PaisExtMASC = "Ecuador";


                    }
                    else
                    {
                        form2.PaisExtMASC = txtPaisExtMASC.Text;
                    }


                    if (string.IsNullOrEmpty(txtINECExtMASC.Text))
                    {

                        form2.INECExtMASC = 0;


                    }
                    else
                    {
                        form2.INECExtMASC = int.Parse(txtINECExtMASC.Text);
                    }





                    form2.DniMASC = int.Parse(txtDniMASC.Text);
                    form2.EstCivilMASC = cmbEstCivilMASC.Text;
                    form2.EtniaMASC = cmbEtniaMASC.Text;
                    form2.LeerMASC = cmbLeerMASC.Text;
                    form2.InstrucMASC = cmbInstrucMASC.Text;
                    form2.ProvMASC = txtProvMASC.Text;
                    form2.CantonMASC = txtCantonMASC.Text;
                    form2.ParroMASC = txtParroMASC.Text;
                    form2.LocalMASC = txtLocalMASC.Text;
                    form2.UInecMASC = int.Parse(txtUInecMASC.Text);
                    form2.FechaNacimientoMASC = dateFechaNacMASC.Text;
                    form2.NumeroMatriMASC = int.Parse(txtNumMatriMASC.Text);
                    form2.EdadMASC = int.Parse(txtEdadMASC.Text);
                    form2.Show();
                    this.Hide();


                }
            }









        }

        private void txtDniMASC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtUInecCAB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtNumActaCAB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtNumHijosCAB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtNumOficinaCAB_KeyUp(object sender, KeyEventArgs e)
        {
        }

        private void txtEdadMASC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtNumMatriMASC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtINECExtMASC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtUInecMASC_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }

        private void txtNumOficinaCAB_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (Char.IsDigit(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsControl(e.KeyChar)) { e.Handled = false; }
            else if (Char.IsSeparator(e.KeyChar)) { e.Handled = false; }
            else { e.Handled = true; }
        }
    }
}
