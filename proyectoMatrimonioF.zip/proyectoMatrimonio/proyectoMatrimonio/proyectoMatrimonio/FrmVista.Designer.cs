﻿namespace proyectoMatrimonio
{
    partial class FrmVista
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.proyectoMatrimonioBDDDataSet = new proyectoMatrimonio.proyectoMatrimonioBDDDataSet();
            this.proyectoMatrimonioBDDDataSetBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.proyectoMatrimonioBDDDataSet1 = new proyectoMatrimonio.proyectoMatrimonioBDDDataSet();
            this.informacionBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.informacionTableAdapter = new proyectoMatrimonio.proyectoMatrimonioBDDDataSetTableAdapters.informacionTableAdapter();
            this.iDCABDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDCUEDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fECHACABDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMBREFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMBREMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView2 = new System.Windows.Forms.DataGridView();
            this.proyectoMatrimonioBDDDataSet11 = new proyectoMatrimonio.proyectoMatrimonioBDDDataSet1();
            this.cONTRAYENTEMASCBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cONTRAYENTE_MASCTableAdapter = new proyectoMatrimonio.proyectoMatrimonioBDDDataSet1TableAdapters.CONTRAYENTE_MASCTableAdapter();
            this.dNIMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDCUEDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMBREMASCDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fECHANACMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eDADMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMMATRIMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nACIONMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pAISEXTMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSOINECEXTMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eSTCIVILMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eTNIAMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lEERMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNSTRUCCIONMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pROVMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cANTONMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARROQUIAMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOCALMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSOINECMASCDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.dataGridView3 = new System.Windows.Forms.DataGridView();
            this.proyectoMatrimonioBDDDataSet2 = new proyectoMatrimonio.proyectoMatrimonioBDDDataSet2();
            this.cONTRAYENTEFEMBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.cONTRAYENTE_FEMTableAdapter = new proyectoMatrimonio.proyectoMatrimonioBDDDataSet2TableAdapters.CONTRAYENTE_FEMTableAdapter();
            this.dNIFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iDCUEDataGridViewTextBoxColumn2 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nOMBREFEMDataGridViewTextBoxColumn1 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.fECHANACFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eDADFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nUMMATRIFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.nACIONFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pAISEXTFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSOINECEXTFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eSTCIVILFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.eTNIAFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lEERFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.iNSTRUCCIONFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pROVFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.cANTONFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.pARROQUIAFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.lOCALFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.uSOINECFEMDataGridViewTextBoxColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSetBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.informacionBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet11)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cONTRAYENTEMASCBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.cONTRAYENTEFEMBindingSource)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            this.dataGridView1.AllowUserToDeleteRows = false;
            this.dataGridView1.AutoGenerateColumns = false;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.iDCABDataGridViewTextBoxColumn,
            this.iDCUEDataGridViewTextBoxColumn,
            this.fECHACABDataGridViewTextBoxColumn,
            this.nOMBREFEMDataGridViewTextBoxColumn,
            this.nOMBREMASCDataGridViewTextBoxColumn});
            this.dataGridView1.DataSource = this.informacionBindingSource;
            this.dataGridView1.Location = new System.Drawing.Point(336, 40);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.ReadOnly = true;
            this.dataGridView1.Size = new System.Drawing.Size(492, 152);
            this.dataGridView1.TabIndex = 0;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(123, 507);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 4;
            this.button1.Text = "REGRESAR";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(333, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(82, 13);
            this.label1.TabIndex = 3;
            this.label1.Text = "INFORMACION";
            // 
            // proyectoMatrimonioBDDDataSet
            // 
            this.proyectoMatrimonioBDDDataSet.DataSetName = "proyectoMatrimonioBDDDataSet";
            this.proyectoMatrimonioBDDDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // proyectoMatrimonioBDDDataSetBindingSource
            // 
            this.proyectoMatrimonioBDDDataSetBindingSource.DataSource = this.proyectoMatrimonioBDDDataSet;
            this.proyectoMatrimonioBDDDataSetBindingSource.Position = 0;
            // 
            // proyectoMatrimonioBDDDataSet1
            // 
            this.proyectoMatrimonioBDDDataSet1.DataSetName = "proyectoMatrimonioBDDDataSet";
            this.proyectoMatrimonioBDDDataSet1.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // informacionBindingSource
            // 
            this.informacionBindingSource.DataMember = "informacion";
            this.informacionBindingSource.DataSource = this.proyectoMatrimonioBDDDataSet1;
            // 
            // informacionTableAdapter
            // 
            this.informacionTableAdapter.ClearBeforeFill = true;
            // 
            // iDCABDataGridViewTextBoxColumn
            // 
            this.iDCABDataGridViewTextBoxColumn.DataPropertyName = "IDCAB";
            this.iDCABDataGridViewTextBoxColumn.HeaderText = "IDCAB";
            this.iDCABDataGridViewTextBoxColumn.Name = "iDCABDataGridViewTextBoxColumn";
            this.iDCABDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // iDCUEDataGridViewTextBoxColumn
            // 
            this.iDCUEDataGridViewTextBoxColumn.DataPropertyName = "IDCUE";
            this.iDCUEDataGridViewTextBoxColumn.HeaderText = "IDCUE";
            this.iDCUEDataGridViewTextBoxColumn.Name = "iDCUEDataGridViewTextBoxColumn";
            this.iDCUEDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // fECHACABDataGridViewTextBoxColumn
            // 
            this.fECHACABDataGridViewTextBoxColumn.DataPropertyName = "FECHACAB";
            this.fECHACABDataGridViewTextBoxColumn.HeaderText = "FECHACAB";
            this.fECHACABDataGridViewTextBoxColumn.Name = "fECHACABDataGridViewTextBoxColumn";
            this.fECHACABDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nOMBREFEMDataGridViewTextBoxColumn
            // 
            this.nOMBREFEMDataGridViewTextBoxColumn.DataPropertyName = "NOMBREFEM";
            this.nOMBREFEMDataGridViewTextBoxColumn.HeaderText = "NOMBREFEM";
            this.nOMBREFEMDataGridViewTextBoxColumn.Name = "nOMBREFEMDataGridViewTextBoxColumn";
            this.nOMBREFEMDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // nOMBREMASCDataGridViewTextBoxColumn
            // 
            this.nOMBREMASCDataGridViewTextBoxColumn.DataPropertyName = "NOMBREMASC";
            this.nOMBREMASCDataGridViewTextBoxColumn.HeaderText = "NOMBREMASC";
            this.nOMBREMASCDataGridViewTextBoxColumn.Name = "nOMBREMASCDataGridViewTextBoxColumn";
            this.nOMBREMASCDataGridViewTextBoxColumn.ReadOnly = true;
            // 
            // dataGridView2
            // 
            this.dataGridView2.AllowUserToAddRows = false;
            this.dataGridView2.AllowUserToDeleteRows = false;
            this.dataGridView2.AutoGenerateColumns = false;
            this.dataGridView2.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView2.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dNIMASCDataGridViewTextBoxColumn,
            this.iDCUEDataGridViewTextBoxColumn1,
            this.nOMBREMASCDataGridViewTextBoxColumn1,
            this.fECHANACMASCDataGridViewTextBoxColumn,
            this.eDADMASCDataGridViewTextBoxColumn,
            this.nUMMATRIMASCDataGridViewTextBoxColumn,
            this.nACIONMASCDataGridViewTextBoxColumn,
            this.pAISEXTMASCDataGridViewTextBoxColumn,
            this.uSOINECEXTMASCDataGridViewTextBoxColumn,
            this.eSTCIVILMASCDataGridViewTextBoxColumn,
            this.eTNIAMASCDataGridViewTextBoxColumn,
            this.lEERMASCDataGridViewTextBoxColumn,
            this.iNSTRUCCIONMASCDataGridViewTextBoxColumn,
            this.pROVMASCDataGridViewTextBoxColumn,
            this.cANTONMASCDataGridViewTextBoxColumn,
            this.pARROQUIAMASCDataGridViewTextBoxColumn,
            this.lOCALMASCDataGridViewTextBoxColumn,
            this.uSOINECMASCDataGridViewTextBoxColumn});
            this.dataGridView2.DataSource = this.cONTRAYENTEMASCBindingSource;
            this.dataGridView2.Location = new System.Drawing.Point(336, 207);
            this.dataGridView2.Name = "dataGridView2";
            this.dataGridView2.ReadOnly = true;
            this.dataGridView2.Size = new System.Drawing.Size(492, 150);
            this.dataGridView2.TabIndex = 5;
            // 
            // proyectoMatrimonioBDDDataSet11
            // 
            this.proyectoMatrimonioBDDDataSet11.DataSetName = "proyectoMatrimonioBDDDataSet1";
            this.proyectoMatrimonioBDDDataSet11.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cONTRAYENTEMASCBindingSource
            // 
            this.cONTRAYENTEMASCBindingSource.DataMember = "CONTRAYENTE_MASC";
            this.cONTRAYENTEMASCBindingSource.DataSource = this.proyectoMatrimonioBDDDataSet11;
            // 
            // cONTRAYENTE_MASCTableAdapter
            // 
            this.cONTRAYENTE_MASCTableAdapter.ClearBeforeFill = true;
            // 
            // dNIMASCDataGridViewTextBoxColumn
            // 
            this.dNIMASCDataGridViewTextBoxColumn.DataPropertyName = "DNIMASC";
            this.dNIMASCDataGridViewTextBoxColumn.HeaderText = "DNIMASC";
            this.dNIMASCDataGridViewTextBoxColumn.Name = "dNIMASCDataGridViewTextBoxColumn";
            // 
            // iDCUEDataGridViewTextBoxColumn1
            // 
            this.iDCUEDataGridViewTextBoxColumn1.DataPropertyName = "IDCUE";
            this.iDCUEDataGridViewTextBoxColumn1.HeaderText = "IDCUE";
            this.iDCUEDataGridViewTextBoxColumn1.Name = "iDCUEDataGridViewTextBoxColumn1";
            // 
            // nOMBREMASCDataGridViewTextBoxColumn1
            // 
            this.nOMBREMASCDataGridViewTextBoxColumn1.DataPropertyName = "NOMBREMASC";
            this.nOMBREMASCDataGridViewTextBoxColumn1.HeaderText = "NOMBREMASC";
            this.nOMBREMASCDataGridViewTextBoxColumn1.Name = "nOMBREMASCDataGridViewTextBoxColumn1";
            // 
            // fECHANACMASCDataGridViewTextBoxColumn
            // 
            this.fECHANACMASCDataGridViewTextBoxColumn.DataPropertyName = "FECHANACMASC";
            this.fECHANACMASCDataGridViewTextBoxColumn.HeaderText = "FECHANACMASC";
            this.fECHANACMASCDataGridViewTextBoxColumn.Name = "fECHANACMASCDataGridViewTextBoxColumn";
            // 
            // eDADMASCDataGridViewTextBoxColumn
            // 
            this.eDADMASCDataGridViewTextBoxColumn.DataPropertyName = "EDADMASC";
            this.eDADMASCDataGridViewTextBoxColumn.HeaderText = "EDADMASC";
            this.eDADMASCDataGridViewTextBoxColumn.Name = "eDADMASCDataGridViewTextBoxColumn";
            // 
            // nUMMATRIMASCDataGridViewTextBoxColumn
            // 
            this.nUMMATRIMASCDataGridViewTextBoxColumn.DataPropertyName = "NUMMATRIMASC";
            this.nUMMATRIMASCDataGridViewTextBoxColumn.HeaderText = "NUMMATRIMASC";
            this.nUMMATRIMASCDataGridViewTextBoxColumn.Name = "nUMMATRIMASCDataGridViewTextBoxColumn";
            // 
            // nACIONMASCDataGridViewTextBoxColumn
            // 
            this.nACIONMASCDataGridViewTextBoxColumn.DataPropertyName = "NACIONMASC";
            this.nACIONMASCDataGridViewTextBoxColumn.HeaderText = "NACIONMASC";
            this.nACIONMASCDataGridViewTextBoxColumn.Name = "nACIONMASCDataGridViewTextBoxColumn";
            // 
            // pAISEXTMASCDataGridViewTextBoxColumn
            // 
            this.pAISEXTMASCDataGridViewTextBoxColumn.DataPropertyName = "PAISEXTMASC";
            this.pAISEXTMASCDataGridViewTextBoxColumn.HeaderText = "PAISEXTMASC";
            this.pAISEXTMASCDataGridViewTextBoxColumn.Name = "pAISEXTMASCDataGridViewTextBoxColumn";
            // 
            // uSOINECEXTMASCDataGridViewTextBoxColumn
            // 
            this.uSOINECEXTMASCDataGridViewTextBoxColumn.DataPropertyName = "USOINECEXTMASC";
            this.uSOINECEXTMASCDataGridViewTextBoxColumn.HeaderText = "USOINECEXTMASC";
            this.uSOINECEXTMASCDataGridViewTextBoxColumn.Name = "uSOINECEXTMASCDataGridViewTextBoxColumn";
            // 
            // eSTCIVILMASCDataGridViewTextBoxColumn
            // 
            this.eSTCIVILMASCDataGridViewTextBoxColumn.DataPropertyName = "ESTCIVILMASC";
            this.eSTCIVILMASCDataGridViewTextBoxColumn.HeaderText = "ESTCIVILMASC";
            this.eSTCIVILMASCDataGridViewTextBoxColumn.Name = "eSTCIVILMASCDataGridViewTextBoxColumn";
            // 
            // eTNIAMASCDataGridViewTextBoxColumn
            // 
            this.eTNIAMASCDataGridViewTextBoxColumn.DataPropertyName = "ETNIAMASC";
            this.eTNIAMASCDataGridViewTextBoxColumn.HeaderText = "ETNIAMASC";
            this.eTNIAMASCDataGridViewTextBoxColumn.Name = "eTNIAMASCDataGridViewTextBoxColumn";
            // 
            // lEERMASCDataGridViewTextBoxColumn
            // 
            this.lEERMASCDataGridViewTextBoxColumn.DataPropertyName = "LEERMASC";
            this.lEERMASCDataGridViewTextBoxColumn.HeaderText = "LEERMASC";
            this.lEERMASCDataGridViewTextBoxColumn.Name = "lEERMASCDataGridViewTextBoxColumn";
            // 
            // iNSTRUCCIONMASCDataGridViewTextBoxColumn
            // 
            this.iNSTRUCCIONMASCDataGridViewTextBoxColumn.DataPropertyName = "INSTRUCCIONMASC";
            this.iNSTRUCCIONMASCDataGridViewTextBoxColumn.HeaderText = "INSTRUCCIONMASC";
            this.iNSTRUCCIONMASCDataGridViewTextBoxColumn.Name = "iNSTRUCCIONMASCDataGridViewTextBoxColumn";
            // 
            // pROVMASCDataGridViewTextBoxColumn
            // 
            this.pROVMASCDataGridViewTextBoxColumn.DataPropertyName = "PROVMASC";
            this.pROVMASCDataGridViewTextBoxColumn.HeaderText = "PROVMASC";
            this.pROVMASCDataGridViewTextBoxColumn.Name = "pROVMASCDataGridViewTextBoxColumn";
            // 
            // cANTONMASCDataGridViewTextBoxColumn
            // 
            this.cANTONMASCDataGridViewTextBoxColumn.DataPropertyName = "CANTONMASC";
            this.cANTONMASCDataGridViewTextBoxColumn.HeaderText = "CANTONMASC";
            this.cANTONMASCDataGridViewTextBoxColumn.Name = "cANTONMASCDataGridViewTextBoxColumn";
            // 
            // pARROQUIAMASCDataGridViewTextBoxColumn
            // 
            this.pARROQUIAMASCDataGridViewTextBoxColumn.DataPropertyName = "PARROQUIAMASC";
            this.pARROQUIAMASCDataGridViewTextBoxColumn.HeaderText = "PARROQUIAMASC";
            this.pARROQUIAMASCDataGridViewTextBoxColumn.Name = "pARROQUIAMASCDataGridViewTextBoxColumn";
            // 
            // lOCALMASCDataGridViewTextBoxColumn
            // 
            this.lOCALMASCDataGridViewTextBoxColumn.DataPropertyName = "LOCALMASC";
            this.lOCALMASCDataGridViewTextBoxColumn.HeaderText = "LOCALMASC";
            this.lOCALMASCDataGridViewTextBoxColumn.Name = "lOCALMASCDataGridViewTextBoxColumn";
            // 
            // uSOINECMASCDataGridViewTextBoxColumn
            // 
            this.uSOINECMASCDataGridViewTextBoxColumn.DataPropertyName = "USOINECMASC";
            this.uSOINECMASCDataGridViewTextBoxColumn.HeaderText = "USOINECMASC";
            this.uSOINECMASCDataGridViewTextBoxColumn.Name = "uSOINECMASCDataGridViewTextBoxColumn";
            // 
            // dataGridView3
            // 
            this.dataGridView3.AllowUserToAddRows = false;
            this.dataGridView3.AllowUserToDeleteRows = false;
            this.dataGridView3.AutoGenerateColumns = false;
            this.dataGridView3.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView3.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.dNIFEMDataGridViewTextBoxColumn,
            this.iDCUEDataGridViewTextBoxColumn2,
            this.nOMBREFEMDataGridViewTextBoxColumn1,
            this.fECHANACFEMDataGridViewTextBoxColumn,
            this.eDADFEMDataGridViewTextBoxColumn,
            this.nUMMATRIFEMDataGridViewTextBoxColumn,
            this.nACIONFEMDataGridViewTextBoxColumn,
            this.pAISEXTFEMDataGridViewTextBoxColumn,
            this.uSOINECEXTFEMDataGridViewTextBoxColumn,
            this.eSTCIVILFEMDataGridViewTextBoxColumn,
            this.eTNIAFEMDataGridViewTextBoxColumn,
            this.lEERFEMDataGridViewTextBoxColumn,
            this.iNSTRUCCIONFEMDataGridViewTextBoxColumn,
            this.pROVFEMDataGridViewTextBoxColumn,
            this.cANTONFEMDataGridViewTextBoxColumn,
            this.pARROQUIAFEMDataGridViewTextBoxColumn,
            this.lOCALFEMDataGridViewTextBoxColumn,
            this.uSOINECFEMDataGridViewTextBoxColumn});
            this.dataGridView3.DataSource = this.cONTRAYENTEFEMBindingSource;
            this.dataGridView3.Location = new System.Drawing.Point(336, 380);
            this.dataGridView3.Name = "dataGridView3";
            this.dataGridView3.ReadOnly = true;
            this.dataGridView3.Size = new System.Drawing.Size(492, 150);
            this.dataGridView3.TabIndex = 6;
            this.dataGridView3.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dataGridView3_CellContentClick);
            // 
            // proyectoMatrimonioBDDDataSet2
            // 
            this.proyectoMatrimonioBDDDataSet2.DataSetName = "proyectoMatrimonioBDDDataSet2";
            this.proyectoMatrimonioBDDDataSet2.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // cONTRAYENTEFEMBindingSource
            // 
            this.cONTRAYENTEFEMBindingSource.DataMember = "CONTRAYENTE_FEM";
            this.cONTRAYENTEFEMBindingSource.DataSource = this.proyectoMatrimonioBDDDataSet2;
            // 
            // cONTRAYENTE_FEMTableAdapter
            // 
            this.cONTRAYENTE_FEMTableAdapter.ClearBeforeFill = true;
            // 
            // dNIFEMDataGridViewTextBoxColumn
            // 
            this.dNIFEMDataGridViewTextBoxColumn.DataPropertyName = "DNIFEM";
            this.dNIFEMDataGridViewTextBoxColumn.HeaderText = "DNIFEM";
            this.dNIFEMDataGridViewTextBoxColumn.Name = "dNIFEMDataGridViewTextBoxColumn";
            // 
            // iDCUEDataGridViewTextBoxColumn2
            // 
            this.iDCUEDataGridViewTextBoxColumn2.DataPropertyName = "IDCUE";
            this.iDCUEDataGridViewTextBoxColumn2.HeaderText = "IDCUE";
            this.iDCUEDataGridViewTextBoxColumn2.Name = "iDCUEDataGridViewTextBoxColumn2";
            // 
            // nOMBREFEMDataGridViewTextBoxColumn1
            // 
            this.nOMBREFEMDataGridViewTextBoxColumn1.DataPropertyName = "NOMBREFEM";
            this.nOMBREFEMDataGridViewTextBoxColumn1.HeaderText = "NOMBREFEM";
            this.nOMBREFEMDataGridViewTextBoxColumn1.Name = "nOMBREFEMDataGridViewTextBoxColumn1";
            // 
            // fECHANACFEMDataGridViewTextBoxColumn
            // 
            this.fECHANACFEMDataGridViewTextBoxColumn.DataPropertyName = "FECHANACFEM";
            this.fECHANACFEMDataGridViewTextBoxColumn.HeaderText = "FECHANACFEM";
            this.fECHANACFEMDataGridViewTextBoxColumn.Name = "fECHANACFEMDataGridViewTextBoxColumn";
            // 
            // eDADFEMDataGridViewTextBoxColumn
            // 
            this.eDADFEMDataGridViewTextBoxColumn.DataPropertyName = "EDADFEM";
            this.eDADFEMDataGridViewTextBoxColumn.HeaderText = "EDADFEM";
            this.eDADFEMDataGridViewTextBoxColumn.Name = "eDADFEMDataGridViewTextBoxColumn";
            // 
            // nUMMATRIFEMDataGridViewTextBoxColumn
            // 
            this.nUMMATRIFEMDataGridViewTextBoxColumn.DataPropertyName = "NUMMATRIFEM";
            this.nUMMATRIFEMDataGridViewTextBoxColumn.HeaderText = "NUMMATRIFEM";
            this.nUMMATRIFEMDataGridViewTextBoxColumn.Name = "nUMMATRIFEMDataGridViewTextBoxColumn";
            // 
            // nACIONFEMDataGridViewTextBoxColumn
            // 
            this.nACIONFEMDataGridViewTextBoxColumn.DataPropertyName = "NACIONFEM";
            this.nACIONFEMDataGridViewTextBoxColumn.HeaderText = "NACIONFEM";
            this.nACIONFEMDataGridViewTextBoxColumn.Name = "nACIONFEMDataGridViewTextBoxColumn";
            // 
            // pAISEXTFEMDataGridViewTextBoxColumn
            // 
            this.pAISEXTFEMDataGridViewTextBoxColumn.DataPropertyName = "PAISEXTFEM";
            this.pAISEXTFEMDataGridViewTextBoxColumn.HeaderText = "PAISEXTFEM";
            this.pAISEXTFEMDataGridViewTextBoxColumn.Name = "pAISEXTFEMDataGridViewTextBoxColumn";
            // 
            // uSOINECEXTFEMDataGridViewTextBoxColumn
            // 
            this.uSOINECEXTFEMDataGridViewTextBoxColumn.DataPropertyName = "USOINECEXTFEM";
            this.uSOINECEXTFEMDataGridViewTextBoxColumn.HeaderText = "USOINECEXTFEM";
            this.uSOINECEXTFEMDataGridViewTextBoxColumn.Name = "uSOINECEXTFEMDataGridViewTextBoxColumn";
            // 
            // eSTCIVILFEMDataGridViewTextBoxColumn
            // 
            this.eSTCIVILFEMDataGridViewTextBoxColumn.DataPropertyName = "ESTCIVILFEM";
            this.eSTCIVILFEMDataGridViewTextBoxColumn.HeaderText = "ESTCIVILFEM";
            this.eSTCIVILFEMDataGridViewTextBoxColumn.Name = "eSTCIVILFEMDataGridViewTextBoxColumn";
            // 
            // eTNIAFEMDataGridViewTextBoxColumn
            // 
            this.eTNIAFEMDataGridViewTextBoxColumn.DataPropertyName = "ETNIAFEM";
            this.eTNIAFEMDataGridViewTextBoxColumn.HeaderText = "ETNIAFEM";
            this.eTNIAFEMDataGridViewTextBoxColumn.Name = "eTNIAFEMDataGridViewTextBoxColumn";
            // 
            // lEERFEMDataGridViewTextBoxColumn
            // 
            this.lEERFEMDataGridViewTextBoxColumn.DataPropertyName = "LEERFEM";
            this.lEERFEMDataGridViewTextBoxColumn.HeaderText = "LEERFEM";
            this.lEERFEMDataGridViewTextBoxColumn.Name = "lEERFEMDataGridViewTextBoxColumn";
            // 
            // iNSTRUCCIONFEMDataGridViewTextBoxColumn
            // 
            this.iNSTRUCCIONFEMDataGridViewTextBoxColumn.DataPropertyName = "INSTRUCCIONFEM";
            this.iNSTRUCCIONFEMDataGridViewTextBoxColumn.HeaderText = "INSTRUCCIONFEM";
            this.iNSTRUCCIONFEMDataGridViewTextBoxColumn.Name = "iNSTRUCCIONFEMDataGridViewTextBoxColumn";
            // 
            // pROVFEMDataGridViewTextBoxColumn
            // 
            this.pROVFEMDataGridViewTextBoxColumn.DataPropertyName = "PROVFEM";
            this.pROVFEMDataGridViewTextBoxColumn.HeaderText = "PROVFEM";
            this.pROVFEMDataGridViewTextBoxColumn.Name = "pROVFEMDataGridViewTextBoxColumn";
            // 
            // cANTONFEMDataGridViewTextBoxColumn
            // 
            this.cANTONFEMDataGridViewTextBoxColumn.DataPropertyName = "CANTONFEM";
            this.cANTONFEMDataGridViewTextBoxColumn.HeaderText = "CANTONFEM";
            this.cANTONFEMDataGridViewTextBoxColumn.Name = "cANTONFEMDataGridViewTextBoxColumn";
            // 
            // pARROQUIAFEMDataGridViewTextBoxColumn
            // 
            this.pARROQUIAFEMDataGridViewTextBoxColumn.DataPropertyName = "PARROQUIAFEM";
            this.pARROQUIAFEMDataGridViewTextBoxColumn.HeaderText = "PARROQUIAFEM";
            this.pARROQUIAFEMDataGridViewTextBoxColumn.Name = "pARROQUIAFEMDataGridViewTextBoxColumn";
            // 
            // lOCALFEMDataGridViewTextBoxColumn
            // 
            this.lOCALFEMDataGridViewTextBoxColumn.DataPropertyName = "LOCALFEM";
            this.lOCALFEMDataGridViewTextBoxColumn.HeaderText = "LOCALFEM";
            this.lOCALFEMDataGridViewTextBoxColumn.Name = "lOCALFEMDataGridViewTextBoxColumn";
            // 
            // uSOINECFEMDataGridViewTextBoxColumn
            // 
            this.uSOINECFEMDataGridViewTextBoxColumn.DataPropertyName = "USOINECFEM";
            this.uSOINECFEMDataGridViewTextBoxColumn.HeaderText = "USOINECFEM";
            this.uSOINECFEMDataGridViewTextBoxColumn.Name = "uSOINECFEMDataGridViewTextBoxColumn";
            // 
            // FrmVista
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 560);
            this.Controls.Add(this.dataGridView3);
            this.Controls.Add(this.dataGridView2);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridView1);
            this.Name = "FrmVista";
            this.Text = "INFORMACION";
            this.Load += new System.EventHandler(this.FrmVista_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSetBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.informacionBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet11)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cONTRAYENTEMASCBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.proyectoMatrimonioBDDDataSet2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.cONTRAYENTEFEMBindingSource)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.BindingSource proyectoMatrimonioBDDDataSetBindingSource;
        private proyectoMatrimonioBDDDataSet proyectoMatrimonioBDDDataSet;
        private proyectoMatrimonioBDDDataSet proyectoMatrimonioBDDDataSet1;
        private System.Windows.Forms.BindingSource informacionBindingSource;
        private proyectoMatrimonioBDDDataSetTableAdapters.informacionTableAdapter informacionTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDCABDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDCUEDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn fECHACABDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMBREFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMBREMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView2;
        private proyectoMatrimonioBDDDataSet1 proyectoMatrimonioBDDDataSet11;
        private System.Windows.Forms.BindingSource cONTRAYENTEMASCBindingSource;
        private proyectoMatrimonioBDDDataSet1TableAdapters.CONTRAYENTE_MASCTableAdapter cONTRAYENTE_MASCTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dNIMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDCUEDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMBREMASCDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn fECHANACMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eDADMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMMATRIMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nACIONMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pAISEXTMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSOINECEXTMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eSTCIVILMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eTNIAMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lEERMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNSTRUCCIONMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pROVMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cANTONMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARROQUIAMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lOCALMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSOINECMASCDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridView dataGridView3;
        private proyectoMatrimonioBDDDataSet2 proyectoMatrimonioBDDDataSet2;
        private System.Windows.Forms.BindingSource cONTRAYENTEFEMBindingSource;
        private proyectoMatrimonioBDDDataSet2TableAdapters.CONTRAYENTE_FEMTableAdapter cONTRAYENTE_FEMTableAdapter;
        private System.Windows.Forms.DataGridViewTextBoxColumn dNIFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iDCUEDataGridViewTextBoxColumn2;
        private System.Windows.Forms.DataGridViewTextBoxColumn nOMBREFEMDataGridViewTextBoxColumn1;
        private System.Windows.Forms.DataGridViewTextBoxColumn fECHANACFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eDADFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nUMMATRIFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn nACIONFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pAISEXTFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSOINECEXTFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eSTCIVILFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn eTNIAFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lEERFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn iNSTRUCCIONFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pROVFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn cANTONFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn pARROQUIAFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn lOCALFEMDataGridViewTextBoxColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn uSOINECFEMDataGridViewTextBoxColumn;
    }
}