﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Sql;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;


namespace proyectoMatrimonio
{
    class Conexion
    {

        SqlConnection cn;
        SqlCommand cmd;
        
        
        public Conexion()
        {
            try
            {
                cn = new SqlConnection("Data Source=(local);Initial Catalog=proyectoMatrimonioBDD;Integrated Security=True ");
                cn.Open();
                MessageBox.Show("Se ha conectado a la base de datos");
            }
            catch (Exception ex)
            {
                MessageBox.Show("No se logro la conexión con la base de datos: " + ex.ToString());
            }
        }

    

        public string insertarREGISTRO_CIVIL(int idOfic, string nombreOfic, int numOfic, string provOfic, string cantonofic, string parroOfic)
        {
            string salida = "Se inserto correctamente";

            try
            {
                cmd = new SqlCommand("Insert into REGISTRO_CIVIL(IDOFIC, NOMBREOFIC, NUMOFIC, PROVOFIC, CANTONOFIC, PARROQUIAOFIC) values(" + idOfic + ", '" + nombreOfic + "', " + numOfic + ", '" + provOfic + "', '" + cantonofic + "', '" + parroOfic + "')", cn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                salida = "No se pudo ingresar los datos" + ex.ToString();

            }
            return salida;
        }



        public string insertarCABECERA_FORMULARIO(int IDCUE, int IDOFIC, string FECHACAB, int USOINECCAB, string FECHAINEC, int ACTACAB, int NUMHIJOSCAB, string CAPBIENESCAB)
        {
            string salida = "Se inserto correctamente";

            try
            {
                cmd = new SqlCommand("Insert into CABECERA_FORMULARIO(IDCUE, IDOFIC, FECHACAB, USOINECCAB, FECHAINEC, ACTACAB, NUMHIJOSCAB, CAPBIENESCAB) values(" + IDCUE + ", " + IDOFIC + ", '" + FECHACAB + "', " + USOINECCAB + ", '" + FECHAINEC + "', " + ACTACAB + ",  " + NUMHIJOSCAB + ", '" + CAPBIENESCAB + "')", cn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                salida = "No se pudo ingresar los datos" + ex.ToString();

            }
            return salida;
        }



        public string insertarCONTRAYENTE_FEM(int DNIFEM, int IDCUE, string NOMBREFEM, string FECHANACFEM, int EDADFEM, int NUMMATRIFEM, string NACIONFEM, string PAISEXTFEM, int USOINECEXTFEM, string ESTCIVILFEM, string ETNIAFEM, string LEERFEM, string INSTRUCCIONFEM, string PROVFEM, string CANTONFEM, string PARROQUIAFEM, string LOCALFEM, int USOINECFEM)
        {
            string salida = "Se ha insertado correctamente la informacion";

            try
            {
                cmd = new SqlCommand("insert into CONTRAYENTE_FEM(DNIFEM,IDCUE,NOMBREFEM,FECHANACFEM,EDADFEM,NUMMATRIFEM,NACIONFEM,PAISEXTFEM,USOINECEXTFEM,ESTCIVILFEM,ETNIAFEM,LEERFEM,INSTRUCCIONFEM,PROVFEM,CANTONFEM,PARROQUIAFEM,LOCALFEM,USOINECFEM) values(" + DNIFEM + ", " + IDCUE + ", '" + NOMBREFEM + "', '" + FECHANACFEM + "', " + EDADFEM + ", " + NUMMATRIFEM + ", '" + NACIONFEM + "', '" + PAISEXTFEM + "', " + USOINECEXTFEM + ", '" + ESTCIVILFEM + "', '" + ETNIAFEM + "', '" + LEERFEM + "', '" + INSTRUCCIONFEM + "', '" + PROVFEM + "', '" + CANTONFEM + "', '" + PARROQUIAFEM + "', '" + LOCALFEM + "', " + USOINECFEM + ")", cn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                salida = "No se pudo ingresar los datos" + ex.ToString();

            }
            return salida;
        }

        public string insertarCONTRAYENTE_MASC(int DNIMASC, int IDCUE, string NOMBREMASC, string FECHANACMASC, int EDADMASC, int NUMMATRIMASC, string NACIONMASC, string PAISEXTMASC, int USOINECEXTMASC, string ESTCIVILMASC, string ETNIAMASC, string LEERMASC, string INSTRUCCIONMASC, string PROVMASC, string CANTONMASC, string PARROQUIAMASC, string LOCALMASC, int USOINECMASC)
        {
            string salida = "Se ha insertado correctamente la informacion";

            try
            {
                cmd = new SqlCommand("insert into CONTRAYENTE_MASC(DNIMASC,IDCUE,NOMBREMASC,FECHANACMASC,EDADMASC,NUMMATRIMASC,NACIONMASC,PAISEXTMASC,USOINECEXTMASC,ESTCIVILMASC,ETNIAMASC,LEERMASC,INSTRUCCIONMASC,PROVMASC,CANTONMASC,PARROQUIAMASC,LOCALMASC,USOINECMASC) values(" + DNIMASC + ", " + IDCUE + ", '" + NOMBREMASC + "', '" + FECHANACMASC + "', " + EDADMASC + ", " + NUMMATRIMASC + ", " + NACIONMASC + ", '" + PAISEXTMASC + "', " + USOINECEXTMASC + ", '" + ESTCIVILMASC + "', '" + ETNIAMASC + "', '" + LEERMASC + "', '" + INSTRUCCIONMASC + "', '" + PROVMASC + "', '" + CANTONMASC + "', '" + PARROQUIAMASC + "', '" + LOCALMASC + "', " + USOINECMASC + ")", cn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                salida = "No se pudo ingresar los datos" + ex.ToString();

            }
            return salida;
        }

        public string insertarCUERPO_FORMULARIO(int DNIRESP, int DNIMASC, int IDCAB, int DNIFEM, int USOINECCUE, string OBSCUE)
        {
            string salida = "Se ha insertado correctamente la informacion";

            try
            {
                cmd = new SqlCommand("insert into CUERPO_FORMULARIO(DNIRESP, DNIMASC, IDCAB, DNIFEM, USOINECCUE, OBSCUE) values(" + DNIRESP + ", " + DNIMASC + ", " + IDCAB + ", " + DNIFEM + ", " + USOINECCUE + ", '" + OBSCUE + "')", cn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                salida = "No se pudo ingresar los datos" + ex.ToString();

            }
            return salida;
        }


        public string insertarRESPONSABLE(int DNIRESP, int IDCUE, string NOMBRERESP)
        {
            string salida = "Se ha insertado correctamente la informacion";

            try
            {
                cmd = new SqlCommand("insert into RESPONSABLE(DNIRESP, IDCUE, NOMBRERESP) values(" + DNIRESP + ", " + IDCUE + ", '" + NOMBRERESP + "')", cn);
                cmd.ExecuteNonQuery();

            }
            catch (Exception ex)
            {
                salida = "No se pudo ingresar los datos" + ex.ToString();

            }
            return salida;
        }

        public void login(string usuario, string contraseña)
        {
            try
            {


                cmd = new SqlCommand("select * from USUARIOS where usuario = @usuario and pass = @pass", cn);

                cmd.Parameters.AddWithValue("@usuario", usuario);
                cmd.Parameters.AddWithValue("@pass", contraseña);
                SqlDataAdapter sda = new SqlDataAdapter(cmd);

                DataTable dt = new DataTable();
                sda.Fill(dt);

                if (dt.Rows.Count == 1)
                {
                    FrmLogin l = new FrmLogin();
                    l.Hide();

                    FrmFormularioP1 formF = new FrmFormularioP1();
                    formF.Show();

                }
                else
                {
                    MessageBox.Show("Usuario no encontrado o mal ingreso de datos");
                }

            }
            catch
            {

            }
            finally
            {

            }
        }



    }
}
