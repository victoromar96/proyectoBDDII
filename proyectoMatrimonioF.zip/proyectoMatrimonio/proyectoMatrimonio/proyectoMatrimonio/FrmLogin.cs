﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace proyectoMatrimonio
{
    public partial class FrmLogin : Form
    {
        Conexion c = new Conexion();

        public FrmLogin()
        {
            InitializeComponent();

            Bitmap img = new Bitmap(Application.StartupPath + @"\imagen\imagen3.jpg");
            this.BackgroundImage = img;
            this.BackgroundImageLayout = ImageLayout.Stretch;


        }

        private void button1_Click(object sender, EventArgs e)
        {
            c.login(txtusuario.Text, txtpass.Text);
        }

        private void FrmLogin_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            FrmVista fr = new FrmVista();
            fr.Show();
            this.Hide();
        }

        private void txtpass_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtusuario_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
